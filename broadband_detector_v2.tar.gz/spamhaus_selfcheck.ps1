# =====================================================================
# Spamhaus PBL environment self-check  (Windows / PowerShell native)
# No WSL / bash / dig required. Uses built-in Resolve-DnsName.
#
# Usage:
#   In PowerShell:  Set-ExecutionPolicy -Scope Process Bypass
#                   .\spamhaus_selfcheck.ps1
#   Or from cmd:    powershell -ExecutionPolicy Bypass -File spamhaus_selfcheck.ps1
#
# Response codes of zen.spamhaus.org:
#   127.0.0.10 / 127.0.0.11  -> PBL hit (residential/dynamic space) = strong HOME evidence
#   empty (NXDOMAIN)         -> not listed (neutral, does NOT mean not residential)
#   127.0.0.2..9             -> SBL/XBL/CSS blacklist (unrelated to residential)
#   127.255.255.x            -> query timeout/error = environment broken
#   198.0.0.x / 198.6.1.x    -> rate-limited / refused (common on public recursive DNS)
# =====================================================================
$ErrorActionPreference = "SilentlyContinue"

$KnownHome = @("24.14.0.1","73.25.0.1","99.170.0.1","84.56.10.1","109.152.0.1","92.135.0.1")  # verified residential IPs (PTR+ASN)
$NonHome   = @("8.8.8.8","1.1.1.1","159.89.1.1")
$DnsServers = @("1.1.1.1","8.8.8.8","")   # "" = system default resolver

function Query-Zen([string]$ip, [string]$server) {
    $parts = $ip -split '\.'
    $rev = "$($parts[3]).$($parts[2]).$($parts[1]).$($parts[0])"
    $q = "$rev.zen.spamhaus.org"
    $res = $null
    if ($server -eq "") { $res = Resolve-DnsName -Name $q -Type A }
    else                { $res = Resolve-DnsName -Name $q -Type A -Server $server }
    $ans = @($res | Where-Object { $_.Type -eq "A" } | Select-Object -ExpandProperty IPAddress)
    if ($ans.Count -eq 0) { return "NXDOMAIN/empty" }
    return ($ans -join ",")
}

function Explain([string]$ans) {
    if ($ans -eq "NXDOMAIN/empty")        { return "not listed (neutral)" }
    if ($ans -eq "TIMEOUT/ERROR")         { return "TIMEOUT/ERROR -> environment broken" }
    if ($ans -match "^(127\.0\.0\.10|127\.0\.0\.11)(,|$)") { return "PBL HIT -> residential strong evidence" }
    if ($ans -match "^127\.0\.0\.")       { return "blacklist code (SBL/XBL/CSS) - unrelated to residential" }
    if ($ans -match "^127\.255\.255\.")   { return "query error -> environment broken" }
    if ($ans -match "^198\.")             { return "rate-limited/refused -> environment broken" }
    return "unknown response"
}

Write-Host "============================================================"
Write-Host "Spamhaus PBL environment self-check"
Write-Host "============================================================"
Write-Host ""
Write-Host "[1/2] Known residential IPs should hit PBL (127.0.0.10/11):"
foreach ($ip in $KnownHome) {
    $a = Query-Zen $ip "1.1.1.1"
    Write-Host ("  {0,-14} via 1.1.1.1 : {1,-22} -> {2}" -f $ip, $a, (Explain $a))
}
Write-Host ""
Write-Host "[2/2] Known non-residential IPs should be NXDOMAIN:"
foreach ($ip in $NonHome) {
    $a = Query-Zen $ip "1.1.1.1"
    Write-Host ("  {0,-14} via 1.1.1.1 : {1,-22} -> {2}" -f $ip, $a, (Explain $a))
}
Write-Host ""
Write-Host "-- Resolver availability (public recursive DNS is often rate-limited):"
foreach ($dns in $DnsServers) {
    $label = if ($dns -eq "") { "system default" } else { $dns }
    $a = Query-Zen "24.14.0.1" $dns
    Write-Host ("  [{0,-10}] 24.14.0.1 : {1,-22} -> {2}" -f $label, $a, (Explain $a))
}
Write-Host ""
Write-Host "Conclusion:"
Write-Host "  - residential IPs return 127.0.0.10/11  -> environment OK, PBL works as strong evidence"
Write-Host "  - all NXDOMAIN                          -> environment OK, those segments not in PBL (normal)"
Write-Host "  - any 127.255.255.x / 198.x / timeout   -> blocked/rate-limited; try your ISP DNS; if still broken, PBL stays 'unknown' (harmless)"
