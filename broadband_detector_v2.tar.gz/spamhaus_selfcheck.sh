#!/usr/bin/env bash
# =====================================================================
# Spamhaus PBL 环境自检 + 查询脚本
# 用法:
#   bash spamhaus_selfcheck.sh                # 环境自检（推荐先跑这个）
#   bash spamhaus_selfcheck.sh <IP...>        # 手动查指定 IP 的 PBL 状态
#
# 原理: PBL = Policy Block List（端用户动态 IP 空间 = 家宽/拨号/动态宽带段）。
# 查询方式: 把 IP 反写 + ".zen.spamhaus.org" 用 dig 查 A 记录。
#   dig +short 1.0.14.24.zen.spamhaus.org   ← 查 24.14.0.1
#
# 响应码:
#   127.0.0.10 / 127.0.0.11  → PBL 命中 → 家宽强证据 (+2)
#   空 (NXDOMAIN)            → 未列入   → 中性（不代表不是家宽）
#   127.0.0.2~9              → SBL/XBL/CSS 黑名单（与家宽无关）
#   127.255.255.254 等       → 查询超时/错误 → 环境有问题
#   198.0.0.x / 198.6.1.x    → 速率限制/拒绝 → 环境有问题（公共递归 DNS 常被限）
# =====================================================================
set -u
command -v dig >/dev/null || { echo "❌ 需要 dig (apt install dnsutils / bind-utils)"; exit 1; }

# ---- 已知家宽段样本（PBL 里应命中 127.0.0.10/11）----
KNOWN_HOME=(
  24.14.0.1     # Comcast 美（hsd1 PTR 已验证家宽）
  73.25.0.1     # Comcast 美
  99.170.0.1    # AT&T DSL 美
  84.56.10.1    # Vodafone DE dslb
  109.152.0.1   # BT UK btcentralplus
  92.135.0.1    # Orange FR abo.wanadoo
)
# ---- 已知非家宽（不应在 PBL）----
NON_HOME=(8.8.8.8 1.1.1.1 159.89.1.1)

DEFAULT_DNSES=("@1.1.1.1" "@8.8.8.8" "")   # "" = 系统默认 DNS

explain() {
  local ans="$1"
  if [ -z "$ans" ]; then echo "  未列入 (NXDOMAIN) → 中性";
  elif [ "$ans" = "127.0.0.10" ] || [ "$ans" = "127.0.0.11" ]; then echo "  ✅ PBL 命中 → 家宽强证据";
  elif [[ "$ans" == 127.0.0.* ]]; then echo "  黑名单类($ans, SBL/XBL/CSS) → 与家宽无关";
  elif [[ "$ans" == 127.255.255.* ]]; then echo "  ❌ 查询错误/超时 → 环境不可用";
  elif [[ "$ans" == 198.* ]]; then echo "  ❌ 速率限制/拒绝($ans) → 环境不可用";
  else echo "  未知响应 $ans";
  fi
}

query_one() {
  local ip="$1" dns="$2"
  local rev=$(echo "$ip" | awk -F. '{print $4"."$3"."$2"."$1}')
  local q="${rev}.zen.spamhaus.org"
  local out
  if [ -z "$dns" ]; then out=$(dig +short +time=4 +tries=2 "$q" 2>&1)
  else out=$(dig +short +time=4 +tries=2 "$dns" "$q" 2>&1); fi
  # dig 错误时 out 可能是空或错误信息
  local first=$(echo "$out" | grep -E '^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$' | head -1)
  if [ -z "$first" ] && echo "$out" | grep -qiE "timed out|timeout"; then
    echo "  查询超时(域名:$q) → 环境不可用"
  else
    echo "$first" | grep -E '^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$' >/dev/null && explain "$first" \
      || { echo "  无响应(域名:$q)"; explain ""; }
  fi
}

if [ $# -gt 0 ]; then
  # 手动查指定 IP
  for ip in "$@"; do
    echo "── $ip ──"
    for dns in "${DEFAULT_DNSES[@]}"; do
      local_label="系统默认DNS"
      [ -n "$dns" ] && local_label="$dns"
      printf "  [%-10s] " "$local_label"
      query_one "$ip" "$dns"
    done
  done
  exit 0
fi

# ---- 自检模式 ----
echo "============================================================"
echo "Spamhaus PBL 环境自检"
echo "============================================================"
echo
echo "[1/2] 已知家宽段应命中 PBL（返回 127.0.0.10/11）:"
for ip in "${KNOWN_HOME[@]}"; do
  printf "  %-14s via 1.1.1.1 : " "$ip"; query_one "$ip" "@1.1.1.1"
done
echo
echo "[2/2] 已知非家宽应未列入（NXDOMAIN）:"
for ip in "${NON_HOME[@]}"; do
  printf "  %-14s via 1.1.1.1 : " "$ip"; query_one "$ip" "@1.1.1.1"
done
echo
echo "── 不同递归 DNS 的可用性（公共递归常被限流）──"
for dns in "${DEFAULT_DNSES[@]}"; do
  local_label="系统默认DNS"
  [ -n "$dns" ] && local_label="$dns"
  printf "  [%-10s] 24.14.0.1 : " "$local_label"; query_one "24.14.0.1" "$dns"
done
echo
echo "判定："
echo "  - 家宽段全部返回 127.0.0.10/11 → 环境可用，PBL 维度能当强证据"
echo "  - 家宽段返回 NXDOMAIN/黑名单码，且非家宽也 NXDOMAIN → 环境可用，但该家宽段不在 PBL（正常，PBL 只收录已知动态空间）"
echo "  - 出现 127.255.255.x / 198.x / 超时 → 环境被限流或 DNS 不通；建议换 ISP 自带 DNS 或本地递归再试；仍不行则脚本会自动记 unknown 不计分"
