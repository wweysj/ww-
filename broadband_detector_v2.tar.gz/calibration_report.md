# 家宽检测器校准报告（第 2 轮 · 国外出口实测）

日期：2026-10-26
出口：US / California / AS906 DMIT Cloud Services / 154.17.224.173
目标：用真实国外出口，对国内外家宽 / 国际云 / 移动网络 / 清单盲区 VPS 做全量回测，验证并校准检测指标与交叉验证逻辑。

---

## 一、校准样本集（34 个，全部有硬证据）

| 组 | 数量 | 样本 | 依据 |
|---|---|---|---|
| HOME 家宽 | 20 | Comcast hsd1×5(24.14/73.25/76.20/24.63/174.160)、Spectrum res×2(96.32/76.180)、AT&T adsl/sbcglobal(99.170)、Verizon VFTTP×2(108.31/98.114)、Cox wsip(68.111)、DT dip0(80.129)、Vodafone dslb(84.56)、Orange abo.wanadoo(92.135)、Virgin cable(86.5)、BT btcentralplus(109.152)、匈Telekom dsl.pool(134.255)、德Pÿur dyn(37.120)、CN电信(183.14)、CN移动(223.73) | PTR 家宽特征词 + 运营商 ASN 双确认（Cymru whois） |
| CLOUD 云/IDC | 11 | AWS×3(3.5.140/15.190/52.34)、GCP×3(34.1/34.35/35.185)、DO(159.89)、Hetzner×2(5.9/88.198)、腾讯云HK(119.28)、Cloudflare(1.1.1.1) | 官方云前缀清单 / PTR 云域名 |
| MOBILE 移动 | 2 | AT&T Mobility(166.137, PTR mycingular)、T-Mobile(172.56) | ASN 移动运营商 |
| 盲区 VPS | 1 | netcup(89.58, AS197540 不在 CLOUD_ASN) | 考验 ip-api hosting 兜底 |

## 二、发现并修复的问题（8 处）

1. **【系统性 bug】Spamhaus PBL 误判**：旧代码 `startswith("127.0.0.")` 前缀匹配会误吞 SBL/XBL 黑名单码(127.0.0.2~9)；且 zen 查询拒绝码 `198.0.0.197` 落入最后分支被判 `signal=-1`，**对所有 IP 系统扣分**，直接把 Cox/Virgin 两个家宽拖成"疑似非家宽"。修复：仅 `127.0.0.10/11` 精确码记 +2 强家宽；`127.255.255.x / 198.0.0.x / 198.6.1.x` 记 unknown；其余(黑名单等)记中性不扣分。
2. **HOME_ASN 缺国外家宽主力**：补入 AT&T 家宽主力 **7018**、Spectrum **11351**、Cox **22773**、Orange **3215**、BT **2856**、Virgin **5089**、Sky **5607**、Magyar Telekom **5483**、Pÿur **50436**（均为校准轮 Cymru 实测确认）。
3. **WHOIS 未接 ARIN 源**：旧代码只查 APNIC/RIPE，美国家宽 WHOIS 恒 unknown。修复为 APNIC→RIPE→ARIN 三源，非归属空间占位(IANA-NETBLOCK)时换下一源。
4. **ip-api ISP 词库扩充 + 移动排除**：补 Cox/Virgin/Sky/Telekom/Kabel/Cable/Telstra/Spark/StarHub/Singtel；**mobile=true 时不再加分**（移动网络不是家宽，避免 Verizon Wireless 等误判家宽方向）。
5. **单维度保护**：无强排除/强家宽覆盖且唯一有向证据为 ±1（弱信号）时 → 降"不确定"；±2 硬信号（asn/ptr/ipapi-hosting 等）单维度仍信任。杜绝"spamhaus -1 单维度判死家宽"类问题，同时保留 netcup 这类 hosting=true 单维度的正确判定。
6. **PTR 词库扩充**：补 dip0(DT)/cable(Virgin)/res(Spectrum)/wsip(Cox)/pon(Virgin FTTP)/wanadoo+abo(Orange)/dyn(Pÿur)。
7. **主动扫描可信度自检**：发现沙箱出口(DMIT)对目标所有 TCP 端口**假握手**（connect 成功但零数据，8.8.8.8:22 也"开放"）→ 旧全量模式 25 端口全"开放"触发 dc_ports 强排除，把家宽误判云。修复：开放端口 ≥ 扫描数 70% 时判定主动扫描不可信，自动禁用主动侧维度。真实网络(用户本机/目标地区出口)不受影响。
8. **WHOIS 运营商词扩充**：补 Cox/Charter/Spectrum/Virgin/Sky/BT/Kabel/Cable/Telekom/Free.fr/SFR/Telstra/Spark/StarHub/Singtel。

## 三、校准后回测结果（34/34 判对）

| 组 | 判定 | 分数范围 |
|---|---|---|
| HOME×20 | 全部 **家宽** | +1.462 ~ +2.000 |
| CLOUD×11 | 全部 **非家宽(云/IDC)** | -2.000 |
| MOBILE×2 | **不确定**（保守，不误判家宽） | 0.000 |
| 盲区VPS(netcup) | **非家宽(云/IDC)**（ip-api hosting 兜底） | -2.000 |

**分数区间完全分离、无重叠** → VERDICT_BANDS(±1.0/±0.4) 验证无需调整，权重结构合理。

## 四、环境限制（部署须知，来自校准实测）

| 能力 | 沙箱状态 | 处置 |
|---|---|---|
| 主动 TCP 扫描 | DMIT 出口对目标全端口假握手(零数据) | 脚本自动检测并禁用主动侧（见 #7）；部署到真实网络即恢复 |
| Spamhaus PBL | ~~zen 返回 198.0.0.197 拒绝码（递归 DNS 被限）~~ **已解决**：脚本改为多 DNS 回退(1.1.1.1→114.114.114.114→8.8.8.8→系统默认)，114.114 在沙箱与用户本机均可查通，PBL 维度已实际参与判定 | PBL 命中=+2 强家宽（mobile=true 时降级+1） |
| ip2region xdb | 55B 占位不可用 | unknown 降级 |
| ARIN WHOIS | 出口可用后已接 ARIN 源 | 美国家宽 WHOIS 维度已恢复 |
| 移动网络 | 两样本均正确"不确定" | mobile 不再是家宽证据 |

## 六、第 3 轮校准（PBL 可用化，2026-10-26）

背景：用户本机 `nslookup ... 114.114.114.114` 查 zen 返回 `127.0.0.10`（PBL 命中）——证明
1.1.1.1/8.8.8.8 被 Spamhaus 限流仅是**递归 DNS 选择问题**，换 114.114.114.114 即可。
为此把 PTR/Spamhaus 两个 dig 维度改为**多 DNS 自动回退**（1.1.1.1 → 114.114.114.114 → 8.8.8.8 → 系统默认；
拒绝码/哨兵的源自动跳过）。

**新回归发现并修复**：PBL 启用后，**移动网络段（AT&T Mobility AS20057 / T-Mobile AS21928）也命中 PBL**
（移动也是"终端用户动态空间"），被误判为"家宽"。修复：ip-api `mobile=true` 时，PBL 命中从 +2 强家宽
降级为 +1 弱证据（移动动态空间≠家宽）。

**终验（全量 34 样本，含 PBL 参与）**：34/34 判对——
- HOME×20 全部"家宽" +1.562~+2.000（PBL 参与后分数整体上浮，多数命中 +2）
- CLOUD×11 全部"非家宽" -1.25~-2.000
- MOBILE×2 正确"不确定"（PBL 降级 + 单维度保护兜底）
- netcup 盲区 "非家宽"（ip-api hosting 兜底）

部署提示：用户本机（Windows）跑检测脚本时，给代理加直连规则放行 `1.1.1.1`(UDP 53)、`114.114.114.114`(UDP 53)、
`*.origin.asn.cymru.com`，可保住 PTR/ASN/Spamhaus 三个 DNS 维度；或直接用系统未劫持的 DNS。

## 七、遗留建议

- CLOUD_ASN 是静态清单：新兴云/区域 CDN 会漏，靠 ip-api hosting 兜底（netcup 已验证兜底有效）；建议周期性从 GitHub 聚合清单更新。
- 家宽 ASN/PTR 词库可持续扩充；遇到新的小运营商随时补。
- 本校准集可作为回归测试集（calibration_run.py），改代码后重跑 34 样本全对再放行。

产物：`broadband_detector.py`(已校准)、`calibration_run.py`、`calibration_results.json`、`calibration_run3.log`
