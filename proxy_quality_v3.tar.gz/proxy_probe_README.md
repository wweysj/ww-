# proxy_probe.py —— 代理节点质量检测工具

最终交付版（`/app/data/tasks/1/proxy_probe.py`）。纯 Python3 stdlib 单文件，风格与
`broadband_detector.py` 一致。基于已实证测量方案（facts #15/#16/#17：协议级探测、
指标定义、批量策略均已本地 mock + 真实链路验证）从 `i13/` 参考实现迁移/完善而来。

## 功能

* 协议支持：**HTTP / HTTPS / SOCKS5** 三类代理，含 `user:pass` 认证
  （HTTP `Proxy-Authorization: Basic`；SOCKS5 RFC1929；HTTPS 代理自动识别
  "外层 TLS" 与 "443 纯 CONNECT" 两种形态并回落重试）。
* 指标（多周期采样统计，默认 6 周期 / 1s 间隔）：
  - 可用性 = 握手 + L2（`/generate_204`，204/2xx/3xx）成功率
  - 延迟 RTT = TCP 连接 + 协议握手 + 首字节（TTFB）的均值/中位/p95 + 分量
  - 抖动 = RTT 样本标准差 + RFC3550 式相邻差均值；丢包 = L2 超时率近似
  - 稳定性 = 成功率 / 最大连败 / 掉线周期 / RTT-CV / 速度 CV → 评级 A~E
  - 上下行速度 = 经隧道拉/推固定测速端点（默认 speed.cloudflare.com 10MB/5MB），
    有效字节 / 耗时（下载扣除 TTFB）；近零 RTT 链路自动加倍载荷并标 `≥`（下限估计）
  - 综合评分 0~100（0.35 可用性 + 0.20 延迟 + 0.20 下载 + 0.10 上传 + 0.15 稳定性）
* 家宽/云归属：复用同目录 `broadband_detector.py.detect(ip, do_active=False,
  do_passive=True)` 对节点 IP 做被动 7 维判定（PTR/ASN/WHOIS/ip-api/ip2region/
  Spamhaus/云清单），并入逐节点报告与对比表。
* 批量：`(scheme,host,port,user)` 保序去重、ThreadPoolExecutor 有界并发、
  分阶段超时预算（TCP 5s / 握手 10s / TTFB 10s / 测速 30s+60s）。
* 输出：文本综合质量报告（逐节点详情 + 汇总对比排名 + 批注）、`--json` 结构化、
  `--csv` 逐节点指标表。

## 用法

```bash
# 单节点
python3 proxy_probe.py http://user:pass@host:8080
python3 proxy_probe.py socks5://host:1080
python3 proxy_probe.py https://host:443

# 列表批量（每行一个，# 注释/空行忽略；非法行收集到报告末尾不中断）
python3 proxy_probe.py -f nodes.txt -w 8

# 常用选项
python3 proxy_probe.py -f nodes.txt --cycles 6 --cycle-gap 1.0 \
    --speed-repeat 2 --no-attribution \
    --json -o report.json --csv report.csv

# 覆盖配置（--cfg KEY=VALUE 可重复）
python3 proxy_probe.py socks5://host:1080 \
    --cfg cycles=3 --cfg download_bytes=20971520 --cfg speed_min_duration=0.5
```

节点规格：`scheme://[user:pass@]host:port`；裸 `host:port` 默认 http；
默认端口 http=80 / https=443 / socks5=1080。`socks4` 不支持（明确报错）。

## 测量端点（可在 CONFIG 中替换）

* 延迟/可用性 L2：`www.gstatic.com/cp.cloudflare.com/speed.cloudflare.com` 的
  `/generate_204`（HTTPS 代理内层走 `1.1.1.1:80` / `example.com:80` 等明文目标，
  因 CPython stdlib 不支持 TLS-in-TLS）。
* 下载：`speed.cloudflare.com/__down?bytes=N`（主）、`speedtest.tele2.net`（后备）；
  上传：`speed.cloudflare.com/__up`。
* 运行环境若无公网访问，测速/可用性指标会失败并如实记录（可用性仍基于可达性）。

## 验证（可复现）

`proxy_probe_validate.py` + `proxy_probe_mocks.py`（本地 mock 代理桩）：
```bash
python3 proxy_probe_validate.py
```
覆盖 9 类确定性场景（HTTP/HTTPS/SOCKS5 × 无认证/正确凭据/凭据缺失/注入延迟丢包）、
测速伪影自适应、真实链路、批量去重并发、归属集成、报告渲染。

## 目录

| 文件 | 说明 |
|---|---|
| `proxy_probe.py` | 主工具（最终交付，仅 stdlib） |
| `proxy_probe_validate.py` | 完整验证脚本（mock 桩 + 真实链路 + 批量 + 报告） |
| `proxy_probe_mocks.py` | 本地 mock 代理 / 测速服务器测试桩（仅测试用） |
| `broadband_detector.py` | 家宽/云归属判定器（复用，被动侧） |