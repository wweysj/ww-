#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
proxy_probe.py —— 代理节点质量检测工具（最终交付版，仅 Python3 stdlib）
================================================================
基于已实证测量方案（facts #15/#16/#17）从 i13/ 参考实现迁移/完善而来。
对给定代理节点（单节点或列表批量）测量：可用性、延迟 RTT、抖动、丢包(近似)、
上下行速度、稳定性（多次采样统计），并复用 broadband_detector.py 对节点 IP
做家宽/云被动归属判定，输出逐节点质量指标 + 归属 + 汇总对比的综合质量报告。

协议支持（含 user:pass 认证）：
  * HTTP  代理 : CONNECT host:port → 200 Connection Established → 裸隧道
                 （Proxy-Authorization: Basic base64(user:pass)，407 触发/校验）
                 另支持 absolute-URI GET（RFC7230 §5.3.2，纯 HTTP 目标直连取）。
  * HTTPS 代理 : 两种现实形态自动识别 ——
                 ① 真外层 TLS 代理（先对代理端口做 TLS,SNI=代理主机,再内层 CONNECT）；
                 ② 443 上纯 CONNECT 代理（商家属常见，外层 TLS 握手失败自动回落）。
                 ★ CPython stdlib 无法对已 TLS 包裹的 socket 再 wrap_socket 做
                   TLS-in-TLS（内层握手读到外层加密字节 → SSLError），故外层 TLS
                   代理内层一律走纯 HTTP 目标（端口 80 的 2xx/3xx 端点）。
  * SOCKS5    : RFC1928 握手（greeting → 方法协商 no-auth / RFC1929 user:pass →
                 CONNECT 请求 ATYP=3 域名(代理侧解析,socks5h) / ATYP=1 IPv4 本地解析
                 → 0x00 成功即隧通）；错误码 0x01~0x08 映射；0xFF=无可接受认证方法。

指标定义（每次"周期"一个样本，多周期统计）：
  availability  = 握手成功 && L2(204/2xx/3xx) 成功 的周期数 / 总周期数
  latency(RTT)  = t_tcp(到代理 TCP) + t_handshake(协议握手) + ttfb(L2 首字节)
                  的均值/中位/p95 + 分量（tcp/handshake/ttfb 各自统计）
  jitter        = RTT 样本标准差(jitter_std) + RFC3550 式相邻样本差均值(jitter_rfc3550)
  loss(近似)    = L2 超时周期 / 总周期数（TCP 无法直测丢包，用多采样超时率近似，报告注明）
  stability     = K 周期成功率 + 最大连续失败(掉线) + 掉线(握手失败)周期数
                  + RTT 变异系数(rtt_cv) + 速度 CV → 综合评级 A~E
  dl/ul speed   = 经隧道拉/推固定测速端点固定大小文件，按有效字节/耗时（下载扣除 TTFB）
                  计算吞吐；★测速伪影修正（fact#16）：近零 RTT（本地/内网）小文件测速会
                  虚高 → 设最短时长下限 speed_min_duration=0.5s，不足则自适应加倍载荷
                  （下载上限 100MB / 上传 50MB，最多 3 次）；若加量后仍低于下限（如突发
                  型链路），报告标 floor_hit 并以 ≥ 提示为下限估计，不虚报精确值。
  quality score = 0~100 综合评分：0.35×可用性 + 0.20×延迟 + 0.20×下载 + 0.10×上传
                  + 0.15×稳定性（公式见 quality_score()，报告附明细；无成功采样时
                  延迟/速度/稳定性分量计 0）。

批量策略（fact#17 实证）：
  * 去重：规范化 spec 后按 (scheme, host, port, user) 保序去重（同节点不同凭据=不同条目）。
  * 并发：ThreadPoolExecutor 有界并发（默认 workers=8），每节点一个 worker，节点内各相
    序贯保证指标干净（不受并发抖动污染）。
  * 超时：分阶段预算 —— TCP connect 5s / 握手 10s / L2 ttfb 10s / 测速 idle 30s+
    total 60s / 单节点整体约 120s；由 socket 超时叠加保证不挂死。

归属集成：importlib 加载同目录 broadband_detector.py，调 detect(ip, do_active=False,
  do_passive=True)（只走被动 7 维：PTR/ASN Cymru/WHOIS/ip-api/ip2region/Spamhaus/
  云前缀清单 —— 校准已证明外部网络全端口假开放时主动扫描不可信），主机名先解析成 IP
  再判，按 IP 缓存，并入节点报告与对比表。

用法：
  python3 proxy_probe.py <spec>... [-f nodes.txt] [-w 8] [--cycles 6] [--cycle-gap 1.0]
        [--speed-repeat 2] [--no-attribution] [--json] [--csv out.csv] [-o report.txt]
        [--cfg KEY=VALUE]...
  节点规格: http://host:port | https://host:port | socks5://[user:pass@]host:port
            裸 host:port 默认 http；默认端口 http=80 / https=443 / socks5=1080
  列表文件: 每行一个节点，# 注释与空行忽略；非法行收集到报告末尾，不中断批量。
  输出：文本综合质量报告（逐节点详情 + 汇总对比排名表 + 批注）；--json 输出结构化
        JSON；--csv 输出逐节点指标 CSV。
"""
import socket, ssl, base64, struct, time, re, threading, json, sys, os, importlib.util
import concurrent.futures as cf

# =====================================================================
# 常量 / 默认配置（测量清单的参数取值，fact#15/16/17 实证）
# =====================================================================
CONNECT_OK_RE   = re.compile(r"HTTP/1\.[01]\s+200\b", re.I)
AUTH_NEED_RE    = re.compile(r"HTTP/1\.[01]\s+407\b", re.I)
TLS_PROXY_ALPN  = ["http/1.1"]

# 延迟/可用性目标端点（固定，HTTPS 优先；每周期轮换 latency_targets[i%len] 防单端点失效）
LATENCY_TARGETS = ["www.gstatic.com:443", "cp.cloudflare.com:443",
                   "speed.cloudflare.com:443", "1.1.1.1:443"]
# 外层 TLS 包裹的 HTTPS 代理：隧道内不能做 TLS-in-TLS（见模块注释）→ 内层走纯 HTTP 目标
LATENCY_TARGETS_PLAIN = ["1.1.1.1:80", "example.com:80", "speed.cloudflare.com:80"]
L2_PATH         = "/generate_204"                      # 期望 204
SPEED_DL_URLS   = [("https://speed.cloudflare.com/__down?bytes={n}", "cf-down"),
                   ("http://speedtest.tele2.net/{size}MB.zip", "tele2"),
                   ("http://speed.cloudflare.com/__down?bytes={n}", "cf-down-http")]
SPEED_UL_URLS   = [("https://speed.cloudflare.com/__up", "cf-up"),
                   ("http://speed.cloudflare.com/__up", "cf-up-http")]
# HTTPS(外层TLS)代理的测速端点：仅 http 明文（避免 TLS-in-TLS）
SPEED_DL_URLS_PLAIN = [("http://speed.cloudflare.com/__down?bytes={n}", "cf-down-http"),
                       ("http://speedtest.tele2.net/{size}MB.zip", "tele2")]
SPEED_UL_URLS_PLAIN = [("http://speed.cloudflare.com/__up", "cf-up-http")]
DOWNLOAD_BYTES  = 10 * 1024 * 1024   # 10MB（下载测速载荷）
UPLOAD_BYTES    = 5 * 1024 * 1024    # 5MB（上传测速载荷）

TIMEOUT = dict(connect=5.0, handshake=10.0, ttfb=10.0, speed_idle=30.0,
               speed_total=60.0, node_budget=120.0)
CYCLES = 6            # 稳定性/抖动/丢包采样周期数
CYCLE_GAP = 1.0       # 周期间隔秒
SPEED_REPEAT = 2      # 速度重复测次数（求 CV=稳定性）

# ★测速伪影修正（fact#16）：近零 RTT 小文件虚高 → 最短时长下限 + 自适应加倍
SPEED_MIN_DURATION = 0.5            # 单次传输最短时长（秒），不足则加量重测
SPEED_MAX_DOWNLOAD = 100 * 1024 * 1024   # 下载载荷上限
SPEED_MAX_UPLOAD   = 50 * 1024 * 1024    # 上传载荷上限

CONFIG = dict(latency_targets=LATENCY_TARGETS,
              latency_targets_plain=LATENCY_TARGETS_PLAIN, l2_path=L2_PATH,
              download_bytes=DOWNLOAD_BYTES, upload_bytes=UPLOAD_BYTES,
              SPEED_DL_URLS=SPEED_DL_URLS, SPEED_UL_URLS=SPEED_UL_URLS,
              SPEED_DL_URLS_PLAIN=SPEED_DL_URLS_PLAIN, SPEED_UL_URLS_PLAIN=SPEED_UL_URLS_PLAIN,
              timeout=TIMEOUT, cycles=CYCLES, cycle_gap=CYCLE_GAP,
              speed_repeat=SPEED_REPEAT, socks5_atyp=3, verify_tls=False,
              speed_min_duration=SPEED_MIN_DURATION,
              speed_max_download=SPEED_MAX_DOWNLOAD, speed_max_upload=SPEED_MAX_UPLOAD,
              broadband_detector="__AUTO__")   # __AUTO__ = 本脚本同目录 broadband_detector.py

# 质量评分权重（0.35 可用性 + 0.20 延迟 + 0.20 下载 + 0.10 上传 + 0.15 稳定性）
SCORE_WEIGHTS = dict(avail=0.35, latency=0.20, dl=0.20, ul=0.10, stability=0.15)
RTT_SCORE_CEIL = 600.0     # RTT≥600ms 延迟分归 0
DL_SCORE_CEIL  = 50.0      # 下载 ≥50Mbps 得满分
UL_SCORE_CEIL  = 20.0      # 上传 ≥20Mbps 得满分


# =====================================================================
# 节点规格：scheme://[user:pass@]host:port
# =====================================================================
class ProxySpec:
    __slots__ = ("scheme", "host", "port", "username", "password", "raw")
    def __init__(self, scheme, host, port, username=None, password=None, raw=""):
        self.scheme, self.host, self.port = scheme.lower(), host.lower(), int(port)
        self.username, self.password, self.raw = username, password, raw
    @property
    def auth_header(self):
        if self.username is None:
            return None
        return "Basic " + base64.b64encode(
            f"{self.username}:{self.password or ''}".encode()).decode()
    @property
    def dedup_key(self):
        """去重键：(scheme, host, port, user)；同节点不同凭据视为不同条目（多账号场景）"""
        return (self.scheme, self.host, self.port, self.username or "")
    def __repr__(self):
        u = f"{self.username}:****@" if self.username else ""
        return f"{self.scheme}://{u}{self.host}:{self.port}"


_SPEC_RE = re.compile(
    r"^(https?|socks5|socks4|socks)://(?:([^:@/]+):([^@/]*)@)?([^:/?#]+)(?::(\d+))?[/]?$",
    re.I)

def parse_spec(s):
    """s: 'http://host:port' | 'socks5://user:pass@host:port' | 'host:port'（默认 http）
    返回 ProxySpec；格式非法抛 ValueError。"""
    s = s.strip()
    if "://" not in s:
        s = "http://" + s
    m = _SPEC_RE.match(s)
    if not m:
        raise ValueError(f"bad proxy spec: {s}")
    scheme, user, pw, host, port = m.group(1), m.group(2), m.group(3), m.group(4), m.group(5)
    if scheme.lower() in ("socks",):
        scheme = "socks5"
    if scheme.lower() == "socks4":
        raise ValueError(f"socks4 不在测量范围（仅 socks5）: {s}")
    if not host:
        raise ValueError(f"bad proxy spec (missing host): {s}")
    port = int(port) if port else {"http": 80, "https": 443, "socks5": 1080}[scheme.lower()]
    return ProxySpec(scheme, host, port, user, pw, s)


def dedup_specs(specs):
    """按 dedup_key 去重，保序，返回 (去重后列表, 丢弃数)"""
    seen, out, dropped = set(), [], 0
    for sp in specs:
        if sp.dedup_key in seen:
            dropped += 1
            continue
        seen.add(sp.dedup_key)
        out.append(sp)
    return out, dropped


# =====================================================================
# TCP / 协议握手
# =====================================================================
def tcp_connect(host, port, timeout):
    t0 = time.time()
    s = socket.create_connection((host, port), timeout=timeout)
    return s, (time.time() - t0) * 1000.0


def _recv_until_headers(sock, timeout):
    """读 HTTP 响应头（\r\n\r\n 前），返回 (status_line, headers_dict)"""
    sock.settimeout(timeout)
    buf = b""
    while b"\r\n\r\n" not in buf:
        d = sock.recv(4096)
        if not d:
            raise ConnectionError("closed before headers")
        buf += d
    head = buf.split(b"\r\n\r\n", 1)[0]
    lines = head.split(b"\r\n")
    status = lines[0].decode("latin1", "replace")
    hdrs = {}
    for ln in lines[1:]:
        if b":" in ln:
            k, v = ln.split(b":", 1)
            hdrs[k.decode("latin1").strip().lower()] = v.decode("latin1").strip()
    return status, hdrs


def http_connect(sock, host, port, auth_header, timeout):
    """HTTP CONNECT → (ok, t_ms, status, need_auth)；200 后 sock 即裸隧道"""
    t0 = time.time()
    req = f"CONNECT {host}:{port} HTTP/1.1\r\nHost: {host}:{port}\r\n"
    if auth_header:
        req += f"Proxy-Authorization: {auth_header}\r\n"
    req += "Proxy-Connection: keep-alive\r\n\r\n"
    sock.sendall(req.encode())
    status, _ = _recv_until_headers(sock, timeout)
    t = (time.time() - t0) * 1000.0
    if CONNECT_OK_RE.search(status):
        return True, t, status, False
    if AUTH_NEED_RE.search(status):
        return False, t, status, True
    return False, t, status, False


SOCKS5_ERR = {1: "general failure", 2: "not allowed", 3: "net unreachable",
              4: "host unreachable", 5: "conn refused", 6: "TTL expired",
              7: "cmd not supported", 8: "addr type not supported"}

def socks5_handshake(sock, host, port, username, password, atyp, timeout):
    """RFC1928+1929 → (ok, t_ms, err_code/描述)"""
    t0 = time.time()
    methods = bytes([0x00])
    if username is not None:
        methods = bytes([0x00, 0x02])
    sock.sendall(b"\x05" + bytes([len(methods)]) + methods)
    sock.settimeout(timeout)
    rep = sock.recv(2)
    if len(rep) != 2 or rep[0] != 5:
        return False, 0, "greeting 响应异常"
    if rep[1] == 0xFF:
        return False, 0, "无可接受认证方法(0xFF)"
    if rep[1] == 0x02:                       # 要求 user/pass
        if username is None:
            return False, 0, "代理要求认证但未提供凭据"
        u, p = username.encode(), (password or "").encode()
        if len(u) > 255 or len(p) > 255:
            return False, 0, "凭据超长"
        sock.sendall(b"\x01" + bytes([len(u)]) + u + bytes([len(p)]) + p)
        r = sock.recv(2)
        if len(r) != 2 or r[1] != 0:
            return False, 0, "user/pass 认证失败(0x01)"
    elif rep[1] != 0x00:
        return False, 0, f"方法被拒(0x{rep[1]:02x})"
    # CONNECT 请求
    is_ip = re.match(r"^\d{1,3}(\.\d{1,3}){3}$", host)
    if is_ip:
        atyp = 1
    if atyp == 3:                            # 域名（socks5h 行为：代理侧解析）
        hb = host.encode()
        addr = bytes([0x03, len(hb)]) + hb
    else:                                    # IPv4：本地解析
        try:
            ip = socket.gethostbyname(host)
        except OSError:
            return False, 0, "本地DNS解析失败(ATYP=1)"
        addr = bytes([0x01]) + socket.inet_aton(ip)
    sock.sendall(b"\x05\x01\x00" + addr + struct.pack(">H", port))
    r = sock.recv(10)                        # 5 + addr(1/4/16) + port(2)
    if len(r) < 4 or r[0] != 5 or r[1] != 0:
        code = r[1] if len(r) >= 2 else -1
        return False, 0, f"CONNECT 失败 0x{code:02x}({SOCKS5_ERR.get(code,'?')})"
    t = (time.time() - t0) * 1000.0
    return True, t, "ok"


def _tls_wrap(sock, server_hostname, timeout):
    """对外层（HTTPS代理）或隧道内（HTTPS目标）做 TLS；verify 默认关（测速端点多为 CDN 证书）"""
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    ctx.set_alpn_protocols(TLS_PROXY_ALPN)
    t = ctx.wrap_socket(sock, server_hostname=server_hostname)
    t.settimeout(timeout)
    return t


# =====================================================================
# 单节点测量
# =====================================================================
class NodeProbe:
    def __init__(self, spec, cfg=None):
        self.spec = spec
        self.cfg = {**CONFIG, **(cfg or {})}
        self.to = self.cfg["timeout"]

    # ---- 隧道建立（返回隧道 socket + 分段时间写入 timing dict） ----
    def open_tunnel(self, host, port, timing):
        """返回隧道 sock；timing dict 原位填充分段时间（异常时 tcp_ms 已写入）"""
        sock, t_tcp = tcp_connect(self.spec.host, self.spec.port, self.to["connect"])
        timing["tcp_ms"] = t_tcp
        if self.spec.scheme == "socks5":
            ok, t_hs, err = socks5_handshake(sock, host, port,
                                             self.spec.username, self.spec.password,
                                             self.cfg["socks5_atyp"], self.to["handshake"])
            timing["handshake_ms"] = t_hs
            if not ok:
                sock.close()
                raise RuntimeError(f"socks5: {err}")
        elif self.spec.scheme == "https":
            # HTTPS 代理两种现实形态：
            #  ① 外层 TLS 包裹的代理（真 TLS 代理）→ 外层 TLS + 内层 CONNECT
            #  ② 443 上纯 CONNECT 代理（商家属常见）→ 外层 TLS 握手失败则回落纯 CONNECT
            outer_ok = False
            try:
                sock = _tls_wrap(sock, self.spec.host, self.to["handshake"])
                outer_ok = True
                timing["proxy_tls_ms"] = 0
            except (OSError, ssl.SSLError):
                try:
                    sock.close()
                except OSError:
                    pass
                sock, t_tcp2 = tcp_connect(self.spec.host, self.spec.port, self.to["connect"])
                timing["tcp_ms"] = t_tcp2
                timing["proxy_tls_ms"] = -1
            ok, t_hs, status, need_auth = http_connect(sock, host, port,
                                                       self.spec.auth_header, self.to["handshake"])
            timing["handshake_ms"] = t_hs
            if need_auth and not self.spec.auth_header:
                sock.close()
                raise RuntimeError("https: 407 需要认证但未提供凭据")
            if not ok:
                sock.close()
                raise RuntimeError(f"https: CONNECT {status}")
        else:  # http
            ok, t_hs, status, need_auth = http_connect(sock, host, port,
                                                       self.spec.auth_header, self.to["handshake"])
            timing["handshake_ms"] = t_hs
            if need_auth and not self.spec.auth_header:
                sock.close()
                raise RuntimeError("http: 407 需要认证但未提供凭据")
            if not ok:
                sock.close()
                raise RuntimeError(f"http: CONNECT {status}")
        timing["connect_ms"] = timing["tcp_ms"] + timing["handshake_ms"]
        return sock

    # ---- L2 应用层验证 + 首字节（经隧道对 generate_204 端点） ----
    def l2_check(self, sock, host, path, timeout, use_tls=True):
        """隧道内 TLS→GET generate_204（端口443）或纯 HTTP（端口80/本地端点）；
        返回 (ok, ttfb_ms, status)"""
        t0 = time.time()
        try:
            tls = _tls_wrap(sock, host, timeout) if use_tls else sock
            req = (f"GET {path} HTTP/1.1\r\nHost: {host}\r\nUser-Agent: proxy-probe/1.0\r\n"
                   f"Connection: close\r\n\r\n")
            tls.sendall(req.encode())
            buf = b""
            while b"\r\n\r\n" not in buf:
                d = tls.recv(4096)
                if not d:
                    break
                buf += d
            ttfb = (time.time() - t0) * 1000.0
            status = buf.split(b"\r\n", 1)[0].decode("latin1", "replace") if buf else ""
            ok = bool(re.search(r"HTTP/1\.[01]\s+(20[0-9]|30[0-9])", status))
            return ok, ttfb, status
        except (OSError, ssl.SSLError) as e:
            return False, (time.time() - t0) * 1000.0, f"{type(e).__name__}"

    # ---- 一个周期样本：选目标→握手→L2 ----
    def cycle(self, target_idx):
        """返回 dict：ok / kind(ok|timeout|hs_fail|conn_fail|auth_fail) / 分段时间 / err"""
        t0 = time.time()
        plain = (self.spec.scheme == "https")  # 外层TLS代理内层只能纯HTTP(见模块注释)
        targets = self.cfg["latency_targets_plain"] if plain else self.cfg["latency_targets"]
        target = targets[target_idx % len(targets)]
        host, _, port = target.partition(":")
        timing = {}
        try:
            sock = self.open_tunnel(host, int(port), timing)
        except RuntimeError as e:
            msg = str(e)
            if "407" in msg or "认证" in msg:
                kind = "auth_fail"
            elif "socks5:" in msg or "CONNECT" in msg:
                kind = "hs_fail"
            else:
                kind = "conn_fail"
            return dict(ok=False, kind=kind, tcp_ms=timing.get("tcp_ms", -1),
                        hs_ms=timing.get("handshake_ms", -1), ttfb_ms=-1, rtt_ms=-1,
                        target=target, err=msg, elapsed=(time.time() - t0) * 1000)
        except (OSError, ssl.SSLError) as e:
            return dict(ok=False, kind="conn_fail", tcp_ms=-1, hs_ms=-1, ttfb_ms=-1,
                        rtt_ms=-1, target=target, err=f"{type(e).__name__}",
                        elapsed=(time.time() - t0) * 1000)
        try:
            ok, ttfb, status = self.l2_check(sock, host, self.cfg["l2_path"], self.to["ttfb"],
                                             use_tls=(int(port) == 443 and not plain))
            hs = timing["handshake_ms"]
            rtt = timing["tcp_ms"] + hs + ttfb
            if not ok:
                kind = "timeout" if "timeout" in status.lower() or "closed" in status else "l2_fail"
                return dict(ok=False, kind=kind, tcp_ms=timing["tcp_ms"], hs_ms=hs,
                            ttfb_ms=ttfb, rtt_ms=rtt, target=target, err=status,
                            elapsed=(time.time() - t0) * 1000)
            return dict(ok=True, kind="ok", tcp_ms=timing["tcp_ms"], hs_ms=hs,
                        ttfb_ms=ttfb, rtt_ms=rtt, target=target, err="",
                        elapsed=(time.time() - t0) * 1000)
        except (OSError, ssl.SSLError) as e:
            return dict(ok=False, kind="timeout", tcp_ms=timing.get("tcp_ms", -1),
                        hs_ms=timing.get("handshake_ms", -1), ttfb_ms=-1, rtt_ms=-1,
                        target=target, err=f"{type(e).__name__}",
                        elapsed=(time.time() - t0) * 1000)
        finally:
            try:
                sock.close()
            except OSError:
                pass

    # ---- 速度测试（经隧道；含测速伪影修正） ----
    def _speed_try(self, url_tmpl, bytes_n, is_upload):
        """单连接单次传输：返回 (mbps, ttfb_ms, dur_s, err, got_bytes)。
        url_tmpl 含 {n}/{size} 占位；下载 dur 扣除 TTFB，上传 dur 含发送+响应。"""
        from urllib.parse import urlparse
        u = urlparse(url_tmpl)
        host, port = u.hostname, u.port or (443 if u.scheme == "https" else 80)
        path = u.path + (("?" + u.query) if u.query else "")
        path = path.replace("{n}", str(bytes_n)).replace("{size}", str(bytes_n // (1024 * 1024)))
        try:
            sock = self.open_tunnel(host, port, {})
        except (RuntimeError, OSError, ssl.SSLError) as e:
            return 0.0, -1, 0.0, f"隧道失败: {e}", 0
        try:
            tls = _tls_wrap(sock, host, self.to["speed_idle"]) if u.scheme == "https" else sock
            t0 = time.time()
            if is_upload:
                body = b"u" * 65536
                req = (f"POST {path} HTTP/1.1\r\nHost: {host}\r\nContent-Length: {bytes_n}\r\n"
                       f"User-Agent: proxy-probe/1.0\r\nConnection: close\r\n\r\n").encode()
                tls.sendall(req)
                left = bytes_n
                while left > 0:
                    k = min(65536, left)
                    tls.sendall(body[:k])
                    left -= k
                buf = b""
                while b"\r\n\r\n" not in buf:
                    d = tls.recv(4096)
                    if not d:
                        break
                    buf += d
                t_end = time.time()
                status = buf.split(b"\r\n", 1)[0].decode("latin1", "replace") if buf else ""
                if not re.search(r"HTTP/1\.[01]\s+2\d\d", status):
                    return 0.0, -1, (t_end - t0), f"上传响应异常: {status}", 0
                dur = t_end - t0
                mbps = (bytes_n * 8 / dur / 1e6) if dur > 0 else 0.0
                return mbps, (t_end - t0) * 1000, dur, "", bytes_n
            else:
                req = (f"GET {path} HTTP/1.1\r\nHost: {host}\r\nUser-Agent: proxy-probe/1.0\r\n"
                       f"Connection: close\r\n\r\n").encode()
                tls.sendall(req)
                buf = b""
                while b"\r\n\r\n" not in buf:
                    d = tls.recv(65536)
                    if not d:
                        break
                    buf += d
                ttfb = (time.time() - t0) * 1000.0
                status = buf.split(b"\r\n", 1)[0].decode("latin1", "replace") if buf else ""
                if not re.search(r"HTTP/1\.[01]\s+2\d\d", status):
                    return 0.0, ttfb, 0.0, f"下载响应异常: {status}", 0
                body = buf.split(b"\r\n\r\n", 1)[1] if b"\r\n\r\n" in buf else b""
                got = len(body)
                t_first = time.time()
                while got < bytes_n:
                    d = tls.recv(65536)
                    if not d:
                        break
                    got += len(d)
                    if got >= bytes_n:
                        break
                t_end = time.time()
                dur = t_end - t_first
                if dur <= 0 or got <= 0:
                    return 0.0, ttfb, dur, f"下载字节不足: {got}/{bytes_n}", got
                mbps = (got * 8 / dur / 1e6)
                return mbps, ttfb, dur, "", got
        except (OSError, ssl.SSLError, ConnectionError) as e:
            return 0.0, -1, 0.0, f"{type(e).__name__}", 0
        finally:
            try:
                sock.close()
            except OSError:
                pass

    def _speed_one_conn(self, url, kind, bytes_n, is_upload):
        """单端点吞吐（自适应加量防伪影）：返回 (speed_mbps, ttfb_ms, err, used_bytes, floor_hit)。
        floor_hit=True 表示最终传输时长仍低于最短下限（近零 RTT/突发链路），报告按下限估计标注 ≥。"""
        max_b = self.cfg["speed_max_upload"] if is_upload else self.cfg["speed_max_download"]
        min_dur = self.cfg.get("speed_min_duration", SPEED_MIN_DURATION)
        best = None   # (mbps, ttfb, got) 最近一次成功测量，用于加量失败时回退
        for attempt in range(3):
            mbps, ttfb, dur, err, got = self._speed_try(url, bytes_n, is_upload)
            if err:
                # 加量重测失败 → 回退到上一次成功测量（而非把速度误报为失败）
                if best is not None:
                    return best[0], best[1], "", best[2], True
                return 0.0, -1, err, 0, False
            floor_hit = dur < min_dur
            best = (mbps, ttfb, bytes_n if is_upload else got)
            # ★伪影修正：传输时长低于下限（近零RTT 虚高）→ 加倍载荷重测（最多3次,上限封顶）
            if not floor_hit or bytes_n >= max_b or attempt >= 2:
                return mbps, ttfb, "", bytes_n if is_upload else got, floor_hit
            bytes_n = min(bytes_n * 2, max_b)
        return 0.0, -1, "测速未收敛", 0, False

    def speed_test(self):
        """下载+上传：逐端点尝试，取首个成功；每项重复 SPEED_REPEAT 次求 CV。
        外层TLS代理(scheme=https)内层仅能纯HTTP → 用 http 明文端点（避免 TLS-in-TLS）。"""
        plain = self.spec.scheme == "https"
        dl_urls = self.cfg.get("SPEED_DL_URLS_PLAIN") if plain else self.cfg.get("SPEED_DL_URLS")
        ul_urls = self.cfg.get("SPEED_UL_URLS_PLAIN") if plain else self.cfg.get("SPEED_UL_URLS")
        res = {"dl_mbps": [], "ul_mbps": [], "dl_ttfb_ms": [], "ul_ttfb_ms": [],
               "dl_bytes": 0, "ul_bytes": 0, "dl_floor_hit": False, "ul_floor_hit": False,
               "endpoint": "", "err": ""}
        for r in range(self.cfg["speed_repeat"]):
            d_ok = u_ok = False
            for tmpl, name in dl_urls:
                mbps, ttfb, err, got, floor = self._speed_one_conn(tmpl, "dl", self.cfg["download_bytes"], False)
                if mbps > 0:
                    res["dl_mbps"].append(mbps); res["dl_ttfb_ms"].append(ttfb)
                    res["dl_bytes"] = got
                    res["dl_floor_hit"] = res["dl_floor_hit"] or floor
                    res["endpoint"] = name; d_ok = True; break
            for tmpl, name in ul_urls:
                mbps, ttfb, err, sent, floor = self._speed_one_conn(tmpl, "ul", self.cfg["upload_bytes"], True)
                if mbps > 0:
                    res["ul_mbps"].append(mbps); res["ul_ttfb_ms"].append(ttfb)
                    res["ul_bytes"] = sent
                    res["ul_floor_hit"] = res["ul_floor_hit"] or floor
                    res["endpoint"] = res["endpoint"] or name; u_ok = True; break
            if not d_ok and not u_ok:
                res["err"] = "速度端点全部失败"
                break
            time.sleep(0.5)
        return res

    # ---- 全量测量 ----
    def measure(self):
        samples = []
        n = self.cfg["cycles"]
        for i in range(n):
            samples.append(self.cycle(i))
            if i < n - 1:
                time.sleep(self.cfg["cycle_gap"])
        oks = [s for s in samples if s["ok"]]
        rtts = [s["rtt_ms"] for s in samples if s["rtt_ms"] > 0]
        n_ok = len(oks)
        availability = n_ok / n
        loss_approx = len([s for s in samples if s["kind"] == "timeout"]) / n   # 丢包≈超时占比
        disconnects = len([s for s in samples if s["kind"] in ("conn_fail", "hs_fail")])  # 掉线(握手失败)
        def stats(v):
            if not v:
                return dict(mean=0, median=0, p95=0, min=0, max=0, std=0)
            v = sorted(v)
            mean = sum(v) / len(v)
            med = v[len(v) // 2]
            p95 = v[min(len(v) - 1, int(len(v) * 0.95))]
            std = (sum((x - mean) ** 2 for x in v) / len(v)) ** 0.5
            return dict(mean=round(mean, 1), median=round(med, 1), p95=round(p95, 1),
                        min=round(v[0], 1), max=round(v[-1], 1), std=round(std, 1))
        # RFC3550 式抖动：相邻样本差均值
        diffs = [abs(b["rtt_ms"] - a["rtt_ms"]) for a, b in zip(samples, samples[1:])
                 if a["rtt_ms"] > 0 and b["rtt_ms"] > 0]
        jitter_rfc = round(sum(diffs) / len(diffs), 1) if diffs else 0.0
        # 最大连续失败（掉线率）
        max_streak = cur = 0
        for s in samples:
            if not s["ok"]:
                cur += 1; max_streak = max(max_streak, cur)
            else:
                cur = 0
        def cv(v):
            if len(v) >= 2 and sum(v) > 0:
                m = sum(v) / len(v)
                return round(((sum((x - m) ** 2 for x in v) / len(v)) ** 0.5) / m, 3)
            return 0.0
        rtt_stats = stats(rtts)
        speed = self.speed_test()
        def avg(v):
            return round(sum(v) / len(v), 2) if v else 0.0
        r = {
            "spec": repr(self.spec), "scheme": self.spec.scheme,
            "host": self.spec.host, "port": self.spec.port,
            "availability": round(availability, 3),
            "ok_cycles": n_ok, "total_cycles": n,
            "loss_approx": round(loss_approx, 3),
            "disconnect_cycles": disconnects, "max_fail_streak": max_streak,
            "rtt": rtt_stats, "jitter_std": rtt_stats["std"], "jitter_rfc3550": jitter_rfc,
            "rtt_cv": cv(rtts),
            "ttfb": stats([s["ttfb_ms"] for s in samples if s["ttfb_ms"] > 0]),
            "handshake": stats([s["hs_ms"] for s in samples if s["hs_ms"] > 0]),
            "tcp": stats([s["tcp_ms"] for s in samples if s["tcp_ms"] > 0]),
            "samples": samples,
            "speed": dict(dl_mbps=[round(x, 2) for x in speed["dl_mbps"]],
                          ul_mbps=[round(x, 2) for x in speed["ul_mbps"]],
                          dl_cv=cv(speed["dl_mbps"]), ul_cv=cv(speed["ul_mbps"]),
                          dl_mean=avg(speed["dl_mbps"]), ul_mean=avg(speed["ul_mbps"]),
                          dl_ttfb_ms=avg(speed["dl_ttfb_ms"]), ul_ttfb_ms=avg(speed["ul_ttfb_ms"]),
                          dl_bytes=speed["dl_bytes"], ul_bytes=speed["ul_bytes"],
                          dl_floor_hit=speed["dl_floor_hit"], ul_floor_hit=speed["ul_floor_hit"],
                          endpoint=speed["endpoint"], err=speed["err"]),
            "elapsed_s": round(sum(s["elapsed"] for s in samples) / 1000, 1),
        }
        r["score"], r["score_breakdown"] = quality_score(r)
        r["stability_grade"] = stability_grade(r)
        return r

    def run(self, with_attribution=True):
        r = self.measure()
        if with_attribution:
            r["attribution"] = node_attribution(self.spec.host, self.cfg)
        return r


# =====================================================================
# 综合质量评分 / 稳定性评级
# =====================================================================
def quality_score(r):
    """0~100 综合评分（权重见 SCORE_WEIGHTS；公式在模块 docstring 注明）：
    avail=可用性×100；lat=clamp(1-rtt_mean/600)×100；dl=min(dl_mean/50,1)×100；
    ul=min(ul_mean/20,1)×100；stab=clamp(100 - jitter_std×1.5 - max_fail_streak×15)。
    无成功样本（ok_cycles=0）时延迟/速度/稳定性分量一律 0（测不到 ≠ 满分）。"""
    ok = r.get("ok_cycles", 0) > 0
    avail = r.get("availability", 0) * 100
    rttm = r["rtt"]["mean"]
    lat = (max(0.0, 1.0 - rttm / RTT_SCORE_CEIL) * 100) if ok and rttm > 0 else 0.0
    dl = (min(r["speed"]["dl_mean"] / DL_SCORE_CEIL, 1.0) * 100) if ok else 0.0
    ul = (min(r["speed"]["ul_mean"] / UL_SCORE_CEIL, 1.0) * 100) if ok else 0.0
    stab = max(0.0, 100 - r["jitter_std"] * 1.5 - r["max_fail_streak"] * 15) if ok else 0.0
    w = SCORE_WEIGHTS
    total = w["avail"] * avail + w["latency"] * lat + w["dl"] * dl + w["ul"] * ul \
            + w["stability"] * stab
    return round(total, 1), dict(avail=round(avail, 1), latency=round(lat, 1),
                                 dl=round(dl, 1), ul=round(ul, 1),
                                 stability=round(stab, 1), weights=w)


def stability_grade(r):
    """稳定性评级 A~E：成功率 + 最大连败 + 抖动"""
    av, streak, jit = r.get("availability", 0), r.get("max_fail_streak", 0), r.get("jitter_std", 0)
    if av >= 0.99 and streak <= 1 and jit <= 50:
        return "A"
    if av >= 0.9 and streak <= 2:
        return "B"
    if av >= 0.75:
        return "C"
    if av >= 0.5:
        return "D"
    return "E"


# =====================================================================
# 家宽/云归属（复用 broadband_detector.py 被动侧）
# =====================================================================
_BD_MOD = None
_BD_LOCK = threading.Lock()
_ATT_CACHE = {}
_HOST_IP_CACHE = {}


def _load_broadband_detector(path):
    global _BD_MOD
    if _BD_MOD is not None:
        return _BD_MOD
    if not os.path.exists(path):
        return None
    spec = importlib.util.spec_from_file_location("broadband_detector", path)
    mod = importlib.util.module_from_spec(spec)
    try:
        spec.loader.exec_module(mod)
        _BD_MOD = mod
    except Exception:
        _BD_MOD = None
    return _BD_MOD


def _default_bd_path():
    """默认定位：本脚本同目录 broadband_detector.py；找不到回退 /app/data/tasks/1/"""
    here = os.path.dirname(os.path.abspath(__file__))
    for p in (os.path.join(here, "broadband_detector.py"),
              "/app/data/tasks/1/broadband_detector.py"):
        if os.path.exists(p):
            return p
    return os.path.join(here, "broadband_detector.py")


def _resolve_host_ip(host):
    """主机名→IP（带缓存）；直接传 IP 原样返回"""
    if re.match(r"^\d{1,3}(\.\d{1,3}){3}$", host):
        return host
    if host in _HOST_IP_CACHE:
        return _HOST_IP_CACHE[host]
    try:
        ip = socket.gethostbyname(host)
    except OSError:
        return None
    _HOST_IP_CACHE[host] = ip
    return ip


def node_attribution(host, cfg=None):
    """对节点主机做归属判定：优先直接传 IP；主机名先解析成 IP 再判。
    复用 broadband_detector.detect(ip, do_active=False, do_passive=True)——代理节点只走
    被动侧（校准：外部全端口假开放时主动扫描不可信）；结果按 IP 缓存。"""
    cfg = cfg or CONFIG
    ip = _resolve_host_ip(host)
    if ip is None:
        return {"ip": host, "error": "解析失败", "verdict": "unknown",
                "confidence": "unknown", "score": 0, "effective_checks": 0}
    with _BD_LOCK:
        if ip in _ATT_CACHE:
            return _ATT_CACHE[ip]
    bd_path = cfg.get("broadband_detector") or "__AUTO__"
    if bd_path == "__AUTO__":
        bd_path = _default_bd_path()
    mod = _load_broadband_detector(bd_path)
    if mod is None:
        r = {"ip": ip, "error": f"broadband_detector 不可用({bd_path})", "verdict": "unknown",
             "confidence": "unknown", "score": 0, "effective_checks": 0}
    else:
        try:
            d = mod.detect(ip, do_active=False, do_passive=True)
            r = {"ip": ip, "verdict": d.get("verdict"), "confidence": d.get("confidence"),
                 "score": d.get("score"), "effective_checks": d.get("effective_checks"),
                 "timestamp": d.get("timestamp"), "error": ""}
        except Exception as e:
            r = {"ip": ip, "error": f"{type(e).__name__}: {str(e)[:80]}", "verdict": "unknown",
                 "confidence": "unknown", "score": 0, "effective_checks": 0}
    with _BD_LOCK:
        _ATT_CACHE[ip] = r
    return r


# =====================================================================
# 批量：并发 / 超时预算 / 去重
# =====================================================================
def run_batch(specs, workers=8, cfg=None, with_attribution=True, progress=None):
    """并发批测：每节点一个 worker（节点内各相序贯保证指标干净）；
    整体线程池有界并发（默认 8）；单节点超时预算由 socket 超时叠加保证。"""
    specs, dropped = dedup_specs(specs)
    out = []
    with cf.ThreadPoolExecutor(max_workers=workers) as ex:
        futs = {ex.submit(NodeProbe(sp, cfg).run, with_attribution): sp for sp in specs}
        for i, f in enumerate(cf.as_completed(futs)):
            sp = futs[f]
            try:
                out.append(f.result())
            except Exception as e:
                out.append({"spec": repr(sp), "scheme": sp.scheme, "host": sp.host,
                            "port": sp.port, "error": f"{type(e).__name__}: {str(e)[:100]}"})
            if progress:
                progress(i + 1, len(specs))
    # 排名：综合评分降序（同分按可用性）
    out.sort(key=lambda r: (r.get("score", -1) if "score" in r else -1,
                            r.get("availability", 0)), reverse=True)
    return {"nodes": out, "dropped_dups": dropped, "total": len(out)}


def load_specs_file(path):
    """读取节点列表文件：每行一个 spec，# 注释与空行忽略；
    返回 (specs[], invalid_lines[{line, error}])，非法行不中断。"""
    specs, invalid = [], []
    with open(path, encoding="utf-8", errors="replace") as fh:
        for ln, raw in enumerate(fh, 1):
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            try:
                specs.append(parse_spec(line))
            except ValueError as e:
                invalid.append({"line": ln, "text": raw.strip(), "error": str(e)})
    return specs, invalid


# =====================================================================
# 报告渲染：文本综合报告 / JSON / CSV
# =====================================================================
def fmt_node(r):
    """单节点文本详情"""
    L = [f"\n{'='*66}", f" 节点: {r.get('spec')}  (scheme={r.get('scheme')})", f"{'='*66}"]
    if "error" in r and "availability" not in r:
        L.append(f" ✗ 测量失败: {r['error']}")
        return "\n".join(L)
    L.append(f" 可用性: {r['availability']*100:.1f}%  ({r['ok_cycles']}/{r['total_cycles']} 周期)")
    L.append(f" 延迟 RTT(ms): mean={r['rtt']['mean']} median={r['rtt']['median']} "
             f"p95={r['rtt']['p95']} min={r['rtt']['min']} max={r['rtt']['max']} "
             f"(tcp={r['tcp']['mean']} hs={r['handshake']['mean']} ttfb={r['ttfb']['mean']})")
    L.append(f" 抖动(ms): std={r['jitter_std']} rfc3550={r['jitter_rfc3550']}   RTT-CV={r['rtt_cv']}")
    L.append(f" 丢包≈超时率: {r['loss_approx']*100:.1f}%   掉线(握手失败)周期: {r['disconnect_cycles']}"
             f"   最大连败: {r['max_fail_streak']}   稳定性评级: {r['stability_grade']}")
    sp = r["speed"]
    dl_s = (">" + str(sp["dl_mean"])) if sp["dl_floor_hit"] and sp["dl_mean"] > 0 else str(sp["dl_mean"])
    ul_s = (">" + str(sp["ul_mean"])) if sp["ul_floor_hit"] and sp["ul_mean"] > 0 else str(sp["ul_mean"])
    L.append(f" 速度: 下载 {dl_s} Mbps (n={len(sp['dl_mbps'])}, cv={sp['dl_cv']}"
             f", ttfb={sp['dl_ttfb_ms']}ms, {sp['dl_bytes']//(1024*1024)}MB"
             f"{'<最短时长' if sp['dl_floor_hit'] else ''}) | "
             f"上传 {ul_s} Mbps (n={len(sp['ul_mbps'])}, cv={sp['ul_cv']}"
             f", {sp['ul_bytes']//(1024*1024)}MB"
             f"{'<最短时长' if sp['ul_floor_hit'] else ''}) @ {sp['endpoint']} {sp['err']}"
             + ("  [近零RTT/突发链路, 速度为下限估计]" if (sp['dl_floor_hit'] or sp['ul_floor_hit']) else ""))
    sb = r["score_breakdown"]
    L.append(f" 综合评分: {r['score']}/100  (可用性{sb['avail']} 延迟{sb['latency']} "
             f"下载{sb['dl']} 上传{sb['ul']} 稳定性{sb['stability']}, 权重{sb['weights']})")
    a = r.get("attribution")
    if a:
        L.append(f" 归属: {a.get('verdict')} (conf={a.get('confidence')}, score={a.get('score')}, "
                 f"eff={a.get('effective_checks')}, ip={a.get('ip')}) {a.get('error','')}")
    return "\n".join(L)


def render_report(res, meta=None, invalid=None):
    """综合质量报告：头部 + 汇总对比排名表 + 逐节点详情 + 批注"""
    L = [f"\n{'='*66}", " 代理节点质量检测报告  |  proxy_probe.py "
                        f"{meta.get('version','')}  |  {meta.get('generated_at','')}", f"{'='*66}"]
    cfg = meta.get("config", {})
    L.append(f" 节点数: {res['total']} (去重丢弃 {res['dropped_dups']} 重复)   "
             f"并发: {cfg.get('workers','?')}   采样周期: {cfg.get('cycles','?')}"
             f" x {cfg.get('cycle_gap','?')}s   测速重复: {cfg.get('speed_repeat','?')}")
    L.append(f" 测速载荷: 下载 {cfg.get('download_bytes',0)//(1024*1024)}MB / "
             f"上传 {cfg.get('upload_bytes',0)//(1024*1024)}MB   归属判定: "
             f"{'开' if meta.get('with_attribution', True) else '关'}")
    nodes = [n for n in res["nodes"] if "availability" in n]
    failed = [n for n in res["nodes"] if "availability" not in n]
    L.append(f"\n [汇总对比] 排名(综合评分降序):  评分 可用%  RTTms  抖动  丢包%  下载  上传  评级  归属")
    for rank, n in enumerate(nodes, 1):
        sp = n["speed"]
        a = n.get("attribution") or {}
        dl = (">" + str(sp['dl_mean'])) if (sp['dl_floor_hit'] and sp['dl_mean'] > 0) else str(sp['dl_mean'])
        L.append(f"  {rank:2d}. {n['spec']:34s} {n['score']:5.1f} {n['availability']*100:4.0f} "
                 f"{n['rtt']['mean']:6.1f} {n['jitter_std']:5.1f} {n['loss_approx']*100:4.0f} "
                 f"{dl:>7s} {sp['ul_mean']:5.2f} {n['stability_grade']:1s}  "
                 f"{a.get('verdict','-')}")
    if failed:
        L.append(f"\n [测量失败节点]")
        for n in failed:
            L.append(f"  ✗ {n.get('spec','?')}: {n.get('error','?')}")
    if nodes:
        av = sum(n["availability"] for n in nodes) / len(nodes)
        rtt = [n["rtt"]["mean"] for n in nodes if n["rtt"]["mean"] > 0]
        dl = [n["speed"]["dl_mean"] for n in nodes if n["speed"]["dl_mean"] > 0]
        L.append(f"\n [批量汇总] 平均可用性 {av*100:.1f}% | 平均RTT "
                 f"{round(sum(rtt)/len(rtt),1) if rtt else 0}ms | 平均下载 "
                 f"{round(sum(dl)/len(dl),2) if dl else 0}Mbps")
        best = nodes[0]
        L.append(f" 最优节点: {best['spec']} (评分 {best['score']})")
    L.append("\n 注: 丢包为 L2 超时率近似(TCP 无法直测); 测速载荷不足最短时长时已自适应加倍;")
    L.append("     RTT 含代理往返; HTTPS 代理内层走纯 HTTP 目标(TLS-in-TLS 受 stdlib 限制).")
    if invalid:
        L.append(f"\n [列表文件非法行 {len(invalid)} 条(已忽略)]")
        for iv in invalid:
            L.append(f"  行{iv['line']}: {iv['text']!r} -> {iv['error']}")
    return "\n".join(L)


def render_json(res, meta=None, invalid=None):
    return json.dumps({"meta": meta or {}, "report": res,
                       "invalid_specs": invalid or []},
                      indent=2, ensure_ascii=False, default=str)


def render_csv(res):
    """逐节点指标 CSV：每节点一行"""
    rows = [["spec", "scheme", "host", "port", "availability", "ok_cycles",
             "rtt_mean_ms", "rtt_median_ms", "rtt_p95_ms", "jitter_std_ms",
             "jitter_rfc3550_ms", "rtt_cv", "loss_approx", "disconnect_cycles",
             "max_fail_streak", "stability_grade", "dl_mbps", "ul_mbps",
             "dl_cv", "ul_cv", "score", "attribution_verdict",
             "attribution_conf", "attribution_score", "error"]]
    import csv, io
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(rows[0])
    for n in res["nodes"]:
        a = n.get("attribution") or {}
        w.writerow([n.get("spec", ""), n.get("scheme", ""), n.get("host", ""),
                    n.get("port", ""), n.get("availability", ""), n.get("ok_cycles", ""),
                    n.get("rtt", {}).get("mean", ""), n.get("rtt", {}).get("median", ""),
                    n.get("rtt", {}).get("p95", ""), n.get("jitter_std", ""),
                    n.get("jitter_rfc3550", ""), n.get("rtt_cv", ""),
                    n.get("loss_approx", ""), n.get("disconnect_cycles", ""),
                    n.get("max_fail_streak", ""), n.get("stability_grade", ""),
                    n.get("speed", {}).get("dl_mean", ""), n.get("speed", {}).get("ul_mean", ""),
                    n.get("speed", {}).get("dl_cv", ""), n.get("speed", {}).get("ul_cv", ""),
                    n.get("score", ""), a.get("verdict", ""), a.get("confidence", ""),
                    a.get("score", ""), n.get("error", "")])
    return buf.getvalue()


# =====================================================================
# CLI
# =====================================================================
def _apply_cfg_override(cfg, kv):
    """--cfg KEY=VALUE：覆盖标量配置（int/float/str 自动识别）"""
    k, _, v = kv.partition("=")
    k = k.strip()
    if not k or not v:
        raise ValueError(f"--cfg 格式: KEY=VALUE, 收到 {kv!r}")
    if k not in cfg:
        raise ValueError(f"--cfg 未知配置键: {k} (可用: {', '.join(sorted(cfg))})")
    if k in ("timeout",) or isinstance(cfg[k], (list, tuple, dict)):
        raise ValueError(f"--cfg 不支持复合配置键 {k}（请改在脚本内 CONFIG 调整）")
    cur = cfg[k]
    if isinstance(cur, bool):
        cfg[k] = v.lower() in ("1", "true", "yes", "on")
    elif isinstance(cur, int):
        cfg[k] = int(v)
    elif isinstance(cur, float):
        cfg[k] = float(v)
    else:
        cfg[k] = v
    return cfg


def main():
    args = sys.argv[1:]
    if not args:
        print(__doc__)
        sys.exit(1)
    specs, workers, cfg, json_out, no_attribution = [], 8, dict(CONFIG), False, False
    csv_path, out_path, file_path = None, None, None
    i = 0
    while i < len(args):
        a = args[i]
        if a in ("-w", "--workers"):
            workers = int(args[i + 1]); i += 2; continue
        if a == "-f":
            file_path = args[i + 1]; i += 2; continue
        if a == "--cycles":
            cfg["cycles"] = int(args[i + 1]); i += 2; continue
        if a == "--cycle-gap":
            cfg["cycle_gap"] = float(args[i + 1]); i += 2; continue
        if a == "--speed-repeat":
            cfg["speed_repeat"] = int(args[i + 1]); i += 2; continue
        if a == "--no-attribution":
            no_attribution = True; i += 1; continue
        if a == "--json":
            json_out = True; i += 1; continue
        if a == "--csv":
            csv_path = args[i + 1]; i += 2; continue
        if a == "-o":
            out_path = args[i + 1]; i += 2; continue
        if a == "--cfg":
            _apply_cfg_override(cfg, args[i + 1]); i += 2; continue
        specs.append(parse_spec(a)); i += 1
    invalid = []
    if file_path:
        fs, invalid = load_specs_file(file_path)
        specs = specs + fs
    if not specs:
        print("错误: 未提供任何有效代理节点（节点列表文件为空或全部非法）。")
        print(__doc__)
        sys.exit(1)
    res = run_batch(specs, workers=workers, cfg=cfg,
                    with_attribution=not no_attribution)
    meta = {"tool": "proxy_probe.py", "version": "1.0.0",
            "generated_at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
            "with_attribution": not no_attribution,
            "config": {**cfg,
                       "workers": workers,
                       "download_bytes": cfg["download_bytes"],
                       "upload_bytes": cfg["upload_bytes"]}}
    text = render_report(res, meta, invalid)
    if json_out:
        body = render_json(res, meta, invalid)
    else:
        body = text
    if out_path:
        with open(out_path, "w", encoding="utf-8") as fh:
            fh.write(body)
    else:
        print(body)
    if csv_path:
        with open(csv_path, "w", encoding="utf-8", newline="") as fh:
            fh.write(render_csv(res))
        print(f"[CSV] 已写出 {csv_path}")
    if out_path:
        print(f"[报告] 已写出 {out_path}")


if __name__ == "__main__":
    main()
