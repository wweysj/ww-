#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
broadband_detector.py —— 家宽 IP 多维检测器
================================================================
整合两路调研成果：
  * 主动探测侧（intent4/fact5）：A 组路由器管理口/UPnP-SSDP/mDNS/游戏P2P端口、
    B 组 TTL/OS、C 组 traceroute 末跳、D 组 TLS 证书、E 组 CDN/云排除
  * 被动数据侧（intent3/fact6）：PTR 特征词、ASN 归属(Cymru)、WHOIS netname、
    ip-api.com 信誉、ip2region 离线库、Spamhaus PBL、云 IP 官方清单
实现：多维度加权评分 + 交叉验证（主动vs被动方向一致性 + 强排除覆盖）+ 置信度输出。

设计要点（来自调研结论）：
  * 先排除再判断：CDN 头 / 云 ASN / 云 PTR / DC 端口组合 / hosting=true / 云前缀清单
    任一命中且无"强家宽"证据 → 直接判非家宽(云/IDC)。
  * 无法取证 ≠ 负分：ICMP 屏蔽、无 PTR(CN 常态)、traceroute 缺失等一律计 0。
  * 每项输出 {signal∈[-2,2], weight, value, confidence: observed|inferred|unknown}。
  * 陷阱：运营商 ASN 段政企混用、家宽自建站+LE 证书像服务器、NAT 端口映射暴露
    内网 Windows 勿误判路由器、移动宽带 CGNAT 与家宽同形、家宽 IP 动态变化→结论带时间戳。
  * 依赖：仅 Python3 stdlib（socket/ssl/struct/subprocess/re/urllib/concurrent）。
    可选外部命令：dig、whois、traceroute（缺失自动降级）。

用法：
  python3 broadband_detector.py <IP> [--json] [--no-active] [--no-passive] [--timeout N]
"""
import socket, ssl, struct, subprocess, re, sys, json, time, os, threading
import concurrent.futures as cf
import urllib.request, urllib.parse

# =====================================================================
# 常量：特征词 / ASN 清单 / 端口 / 权重
# =====================================================================

# --- PTR 特征词（fact6 实测命中 + fact5 归纳） ---
PTR_HOME_RX = re.compile(
    r"hsd1|subs?\.|dslb|dsl\.|dynamic|dyn\.|cust\.|subscriber|lightspeed|qwest|vfttp|threembb|"
    r"btcentralplus|rev\.sfr|pools\.|pppoe|pppoa|ppp\.|adsl|vdsl|broadband|"
    r"bras|bng|access|cmts|olt|gpon|onu|dial|radius|cpe|home|"
    r"dip0|cable\.|res\.|wsip|pon\.|wanadoo|abo\.", re.I)
PTR_CLOUD_RX = re.compile(
    r"amazonaws\.com|googleusercontent\.com|your-server\.de|ovh\.net|ovh\.com|"
    r"digitalocean|linode|vultr|azure|cloudapp|cloudfront|fastly|akama|"
    r"cdn\.|datacenter|\bdc\d*-|colo|hosting|hetzner|scaleway", re.I)

# --- 家宽运营商 ASN（fact6 调研 + 校准轮实测确认；CN 骨干 4837 + 省级 17816 等） ---
HOME_ASN = {
    4134, 9808, 4837, 17816, 9394, 4812, 9929,      # CN 电信/移动/联通/铁通
    7922, 7016, 33650, 20001, 20115,               # Comcast / Spectrum
    701, 6389, 6167, 4323, 11427, 7018, 11351, 22773,  # AT&T / 时代华纳 / Spectrum(TWC) / Cox（美，校准实测）
    3320, 3209, 3327, 6830, 6849, 5430, 8426, 1257, 3269, 15557, 3215,  # 欧洲电信（DT/Vodafone/Orange/Liberty/Telia/SFR/Swisscom等；3215=Orange FR 校准实测）
    2856, 5089, 5607,                              # BT / Virgin Media / Sky（英，校准实测）
    5483, 50436,                                   # Magyar Telekom(HU) / Pÿur(DE)（校准实测）
    9506, 4771, 23655,                            # 新西兰Spark / 澳Telstra / 新加坡StarHub
}
# --- 云 / IDC / CDN ASN（fact6 实测 + 官方文档） ---
CLOUD_ASN = {
    14061, 24940, 45102, 132203, 16509, 8075, 396982, 16276, 63949, 31898,  # DO/Hetzner/阿里/腾讯/Amazon/MS/Google/OVH/Linode/Oracle
    20473, 45090, 37963, 134771, 13335, 15169, 14618, 20940, 54113, 55967,  # Vultr/腾讯云CN/阿里云CN/华为云/Cloudflare/Google/AWS-CloudFront/Akamai/百度/腾讯CDN
    200130, 200010, 9009, 12876, 206264,           # Leaseweb/Webself/M247/Online SAS/Quantum
    8072, 8093, 20712, 397318, 55081,             # 微软/AWS-2/AWS-3/AWS/Edgio(LLNW)
    16509, 16550, 63199,                          # Amazon 系列
}

# --- 端口组 ---
ROUTER_PORTS = [80, 443, 8080, 8443]
DC_PORTS     = [25, 110, 143, 993, 3306, 5432, 6379, 27017, 8888]
GAMING_PORTS = [51413, 3074, 27015, 27016, 3724, 3659, 5500, 9988, 6881, 6889]
WEAK_PORTS   = [22, 3389]
ALL_SCAN_PORTS = sorted(set(ROUTER_PORTS + DC_PORTS + GAMING_PORTS + WEAK_PORTS))

# --- 路由器管理页指纹（fact5 A1 词库） ---
ROUTER_FP = [
    (re.compile(r"TP-?LINK|WR\d{3,4}[A-Z]?", re.I), "TP-Link"),
    (re.compile(r"ASUSWRT|RT-AC\d+|ASUS ROUTER|RT-AX\d+", re.I), "ASUS"),
    (re.compile(r"HUAWEI|HG\d+|Home Gateway|ONT|OptiXstar", re.I), "Huawei"),
    (re.compile(r"ZXHN|F\d{3}", re.I), "ZTE"),
    (re.compile(r"MiWiFi|Xiaomi Router|Redmi Router|Xiaomi.*[Rr]outer", re.I), "Xiaomi"),
    (re.compile(r"OpenWrt|LuCI|uhttpd", re.I), "OpenWrt"),
    (re.compile(r"DD-WRT", re.I), "DD-WRT"),
    (re.compile(r"Tomato|FreshTomato", re.I), "Tomato"),
    (re.compile(r"RouterOS|MikroTik|webfig", re.I), "MikroTik"),
    (re.compile(r"NETGEAR|ReadySHARE|R[0-9]{4}", re.I), "Netgear"),
    (re.compile(r"D-Link|DLINK|DES-|DIR-", re.I), "D-Link"),
    (re.compile(r"Tenda", re.I), "Tenda"),
    (re.compile(r"ciscoweb|Cisco Router|Cisco", re.I), "Cisco"),
    (re.compile(r"Ruijie|锐捷|EG\d{3}", re.I), "Ruijie"),
    (re.compile(r"Luma|Eero|Linksys|Belkin|Archer|A7|A6", re.I), "Consumer-Router"),
]

# --- CDN 响应头（fact5 E1） ---
CDN_HEADER_RX = [
    (re.compile(r"server:\s*cloudflare", re.I), "cloudflare"),
    (re.compile(r"cf-ray:|cf-cache-status:", re.I), "cloudflare"),
    (re.compile(r"x-served-by:|x-cache:|x-cache-hits:|x-amz-cf-|x-azure-|age:|via:|fastly|akamai|google", re.I), "cdn-edge"),
]

# --- traceroute 末跳特征词（fact5 C1） ---
TR_ACCESS_RX = re.compile(
    r"bras|bng|access|ppp|pppoe|dsl|dslite|cmts|olt|gpon|onu|radius|dial|customer|"
    r"subscriber|dynamic|adsl|vdsl|ntt|telecom|comcast|vodafone|chinatelecom|chinanet|unicom|cmnet", re.I)
TR_DC_RX = re.compile(r"colo|datacenter|\bdc\b|core|edge|rack|hosting|idc|cloud", re.I)

# --- WHOIS netname/org/descr 特征（fact6） ---
WHOIS_CLOUD_RX = re.compile(r"cloud|datacenter|hosting|idc|-dc\d|\bdc\d+\b|colo", re.I)
WHOIS_CARRIER_RX = re.compile(r"CHINANET|CMNET|CHINA169|UNICOM|China Telecom|China Mobile|"
                               r"Comcast|AT&T|Vodafone|Telecom|Telekom|Orange|Verizon|CenturyLink|"
                               r"Deutsche Telekom|Cox|Charter|Spectrum|Virgin|Sky|BT|Kabel|Cable|"
                               r"Free\.fr|SFR|Telstra|Spark|StarHub|Singtel", re.I)

# --- 权重（signal∈[-2,2] × weight；可调） ---
WEIGHTS = {
    # 被动侧
    "ptr":       1.5,   # PTR 特征词
    "asn":       3.0,   # ASN 归属（家宽/云最高区分度）
    "whois":     1.5,   # WHOIS netname/descr
    "ipapi":     2.0,   # ip-api.com hosting/proxy/isp
    "ip2region": 1.0,   # 离线 ISP 字段
    "spamhaus":  1.5,   # PBL DNSBL
    "cloudlist": 3.0,   # 云前缀清单命中
    # 主动侧
    "router_admin": 3.0,  # A1 路由器管理口指纹
    "ssdp":         3.0,  # A2 UPnP/SSDP
    "mdns":         0.5,  # A3 mDNS
    "gaming":       0.5,  # A4 游戏/P2P 端口
    "weak_ports":   0.3,  # A5 22/3389
    "dc_ports":     3.0,  # A6 数据中心端口组合
    "ttl":          0.5,  # B1 TTL
    "traceroute":   1.5,  # C traceroute 末跳
    "tls":          2.0,  # D TLS 证书
    "cdn_headers":  3.0,  # E1 CDN 响应头
}

VERDICT_BANDS = [  # (下界, 家宽方向分数) -> 判定
    (1.00, "家宽"),
    (0.40, "疑似家宽"),
    (-0.40, "不确定"),
    (-1.00, "疑似非家宽(云/IDC)"),
    (-9.99, "非家宽(云/IDC)"),
]

# =====================================================================
# 工具函数
# =====================================================================

def run_cmd(cmd, timeout=10):
    """跑外部命令，返回 (rc, stdout, stderr)；异常返回 (None,'','')"""
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return p.returncode, p.stdout, p.stderr
    except (subprocess.TimeoutExpired, FileNotFoundError, OSError) as e:
        return None, "", str(e)


def tcp_scan(ip, ports, timeout=2.0, workers=32):
    """并发 TCP connect 扫描，返回 {port: True/False}"""
    res = {}

    def one(p):
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(timeout)
        t0 = time.time()
        try:
            s.connect((ip, p))
            return p, True
        except OSError:
            return p, False
        finally:
            s.close()

    with cf.ThreadPoolExecutor(max_workers=workers) as ex:
        for p, ok in ex.map(one, ports):
            res[p] = ok
    return res


def http_get(ip, port, timeout=4.0, path=b"/"):
    """GET 取 (status_line, headers_dict, body_head)；失败 None"""
    try:
        s = socket.create_connection((ip, port), timeout=timeout)
        req = b"GET " + path + b" HTTP/1.1\r\nHost: " + ip.encode() + \
              b"\r\nUser-Agent: Mozilla/5.0 (compatible; BroadbandDetector/1.0)\r\nAccept: */*\r\nConnection: close\r\n\r\n"
        s.sendall(req)
        data = b""
        s.settimeout(timeout)
        while True:
            chunk = s.recv(4096)
            if not chunk:
                break
            data += chunk
            if len(data) > 65536:
                break
        s.close()
        head, _, rest = data.partition(b"\r\n\r\n")
        lines = head.split(b"\r\n")
        status = lines[0].decode("latin1", "replace") if lines else ""
        hdrs = {}
        for ln in lines[1:]:
            if b":" in ln:
                k, v = ln.split(b":", 1)
                hdrs[k.decode("latin1").lower().strip()] = v.decode("latin1", "replace").strip()
        return status, hdrs, rest[:2048]
    except OSError:
        return None


def icmp_ping(ip, timeout=3.0):
    """ICMP echo 拿响应 TTL；失败返回 None（权限不足自动降级 ping 命令）"""
    # 优先 raw socket
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_RAW, socket.IPPROTO_ICMP)
        s.settimeout(timeout)
        icmp = struct.pack(">BBHHH", 8, 0, 0, 1, 1) + b"\x00" * 48
        s.sendto(icmp, (ip, 0))
        t0 = time.time()
        while time.time() - t0 < timeout:
            pkt, addr = s.recvfrom(256)
            if addr[0] == ip and pkt[20] == 0:  # echo reply
                return pkt[8]
        s.close()
        return None
    except PermissionError:
        pass
    except (socket.timeout, OSError):
        return None
    # 降级：ping 命令解析 ttl=
    rc, out, _ = run_cmd(["ping", "-c", "1", "-W", "2", ip], timeout=timeout + 2)
    if rc == 0:
        m = re.search(r"ttl=(\d+)", out, re.I)
        if m:
            return int(m.group(1))
    return None


def initial_ttl(ttl_observed):
    """响应 TTL → 初始 TTL（32/64/128/255）"""
    for v in (32, 64, 128, 255):
        if ttl_observed <= v:
            return v
    return 255


# =====================================================================
# 被动侧：P1 PTR / P2 ASN / P3 WHOIS / P4 ip-api / P5 ip2region / P6 Spamhaus / P7 云清单
# =====================================================================

def p1_ptr(ip, dns="1.1.1.1"):
    """PTR 反向解析（多递归回退：1.1.1.1 → 114.114.114.114 → 8.8.8.8 → 系统默认；
    遇拒绝码(198.x/哨兵)自动换源——校准：公共递归对 Spamhaus 限流，PTR 源被限时换 DNS）"""
    for d in (dns, "114.114.114.114", "8.8.8.8", ""):
        args = ["dig", "+short", "+time=4", "+tries=2"]
        if d:
            args += [f"@{d}"]
        args += ["-x", ip]
        rc, out, _ = run_cmd(args, timeout=12)
        if rc != 0:
            continue
        # 拒绝码/哨兵 → 该源无效,换下一个
        if any(ln.strip().startswith(("198.", "127.255.255.")) for ln in out.splitlines() if ln.strip() and not ln.strip().startswith(";")):
            continue
        name = out.strip().rstrip(".")
        if not name:
            return {"signal": 0, "weight": WEIGHTS["ptr"], "value": "无PTR(NXDOMAIN/NODATA,CN家宽常态)",
                    "confidence": "observed", "dim": "ptr", "detail": f"dig @{d or 'system'} -x 无 A/PTR 记录"}
        if PTR_HOME_RX.search(name):
            sig, conf, val = +2, "observed", f"PTR含家宽特征词: {name}"
        elif PTR_CLOUD_RX.search(name):
            sig, conf, val = -2, "observed", f"PTR含云域名: {name}"
        else:
            sig, conf, val = 0, "observed", f"PTR无特征词: {name}"
        return {"signal": sig, "weight": WEIGHTS["ptr"], "value": val,
                "confidence": conf, "dim": "ptr", "detail": name}
    return {"signal": 0, "weight": WEIGHTS["ptr"], "value": "PTR查询失败(所有DNS源不可用)",
            "confidence": "unknown", "dim": "ptr", "detail": ""}


def p2_asn(ip):
    """Team Cymru whois → ASN/AS名/CC（免费无 key）"""
    rc, out, _ = run_cmd(["whois", "-h", "whois.cymru.com", " -v " + ip], timeout=15)
    if rc != 0 or not out:
        return {"signal": 0, "weight": WEIGHTS["asn"], "value": "Cymru不可用",
                "confidence": "unknown", "dim": "asn", "detail": ""}
    lines = out.strip().splitlines()
    if not lines:
        return {"signal": 0, "weight": WEIGHTS["asn"], "value": "Cymru空响应",
                "confidence": "unknown", "dim": "asn", "detail": ""}
    # Cymru 输出：表头 `AS | IP | BGP Prefix | CC | Registry | Allocated | AS Name`
    #           数据行 `16509   | 52.34.123.1      | ...`（行首是 ASN，无前导竖线）
    data_line = next((ln for ln in lines[1:] if ln.strip() and ln.strip()[0].isdigit()), lines[0])
    m = re.match(r"^\s*(\d+)\s*\|\s*([^|]*)\|\s*([^|]*)\|\s*([^|]*)\|\s*([^|]*)\|\s*([^|]*)\|\s*(.*)$", data_line)
    if not m:
        return {"signal": 0, "weight": WEIGHTS["asn"], "value": "Cymru解析失败",
                "confidence": "unknown", "dim": "asn", "detail": out[:200]}
    asn = int(m.group(1))
    descr = (m.group(7).strip() or m.group(6).strip() or m.group(5).strip())  # AS Name / Allocated / Registry
    cc = m.group(4).strip()
    if asn in CLOUD_ASN:
        sig, conf, val = -2, "observed", f"云/IDC ASN: AS{asn} {descr}"
    elif asn in HOME_ASN:
        sig, conf, val = +2, "observed", f"家宽运营商 ASN: AS{asn} {descr}"
    else:
        sig, conf, val = 0, "observed", f"AS{asn} {descr}（不在家宽/云清单）"
    return {"signal": sig, "weight": WEIGHTS["asn"], "value": val,
            "confidence": conf, "dim": "asn", "detail": f"AS{asn} {descr} CC={cc}"}


def p3_whois(ip):
    """WHOIS netname/org/descr（APNIC→RIPE→ARIN 顺序；ARIN 空间在出口可用时以 whois.arin.net 为准，
    APNIC/RIPE 对 ARIN 空间返回 IANA-NETBLOCK 占位时继续尝试下一源）"""
    for host in ("whois.apnic.net", "whois.ripe.net", "whois.arin.net"):
        rc, out, _ = run_cmd(["whois", "-h", host, ip], timeout=15)
        if rc != 0:
            continue
        blob = out
        netname = ""
        for key in ("netname:", "NetName:", "org-name:", "orgname:", "OrgName:"):
            m = re.search(rf"(?im)^{key}\s+(.+)$", blob)
            if m:
                netname = m.group(1).strip()
                break
        descr = ""
        m = re.search(r"(?im)^descr:\s+(.+)$", blob)
        if m:
            descr = m.group(1).strip()
        if not netname and not descr:
            continue
        blob2 = netname + " " + descr
        if re.search(r"IANA-NETBLOCK|not allocated to APNIC|not allocated to RIPE|not allocated to ARIN", blob2, re.I):
            # 非本源归属空间的占位说明 → 换下一个源
            continue
        if WHOIS_CLOUD_RX.search(blob2):
            sig, conf, val = -2, "observed", f"netname/descr含云/IDC词: {netname} | {descr[:80]}"
        elif WHOIS_CARRIER_RX.search(blob2):
            sig, conf, val = +1, "observed", f"netname含运营商特征: {netname} | {descr[:80]}"
        else:
            sig, conf, val = 0, "observed", f"netname无特征词: {netname}"
        return {"signal": sig, "weight": WEIGHTS["whois"], "value": val,
                "confidence": conf, "dim": "whois", "detail": f"{netname} | {descr[:160]}"}
    # 所有源均无有效 netname/descr
    return {"signal": 0, "weight": WEIGHTS["whois"], "value": "WHOIS无netname/descr信息",
            "confidence": "unknown", "dim": "whois", "detail": ""}


def p4_ipapi(ip):
    """ip-api.com 免费：isp/org/as/asname/country/proxy/hosting/mobile（偶发超时→重试3次）"""
    last_err = None
    for attempt in range(3):
        try:
            url = "http://ip-api.com/json/" + ip + "?fields=status,country,isp,org,as,asname,proxy,hosting,mobile,query"
            with urllib.request.urlopen(url, timeout=15) as r:
                d = json.loads(r.read().decode())
            break
        except Exception as e:
            last_err = f"{type(e).__name__}:{str(e)[:60]}"
            time.sleep(2)
    else:
        return {"signal": 0, "weight": WEIGHTS["ipapi"], "value": f"ip-api重试3次仍失败: {last_err}",
                "confidence": "unknown", "dim": "ipapi", "detail": last_err or ""}
    if d.get("status") != "success":
        return {"signal": 0, "weight": WEIGHTS["ipapi"], "value": "ip-api失败",
                "confidence": "unknown", "dim": "ipapi", "detail": str(d)[:120]}
    hosting, proxy, mobile = bool(d.get("hosting")), bool(d.get("proxy")), bool(d.get("mobile"))
    sig = 0
    notes = []
    if hosting:
        sig -= 2
        notes.append("hosting=true(数据中心特征)")
    if proxy:
        sig -= 1
        notes.append("proxy=true")
    if mobile:
        notes.append("mobile=true(移动宽带CGNAT,非家宽但也不排除)")
    isp = d.get("isp", "") or ""
    ISP_HOME_RX = re.compile(
        r"CHINANET|ChinaNet|China Telecom|China Mobile|China Unicom|Comcast|Vodafone|Orange|"
        r"Deutsche Telekom|Charter|CenturyLink|BT|Verizon|AT&T|Telia|Swisscom|SFR|Free\.fr|"
        r"Cox|Virgin|Sky|Telekom|Kabel|Cable|Telstra|Spark|StarHub|Singtel", re.I)
    if ISP_HOME_RX.search(isp) and not hosting and not mobile:
        sig += 1
        notes.append(f"ISP名含家宽运营商: {isp}")
    if hosting:
        val = f"hosting=true → 云/IDC (isp={isp})"
        conf = "observed"
    else:
        val = f"hosting=false (isp={isp}; {'; '.join(notes) if notes else '无异常标志'})"
        conf = "observed"
    sig = max(-2, min(2, sig))
    return {"signal": sig, "weight": WEIGHTS["ipapi"], "value": val,
            "confidence": conf, "dim": "ipapi",
            "mobile": bool(mobile),
            "detail": json.dumps(d, ensure_ascii=False)[:200]}


_IP2REGION = None

def _load_ip2region(xdb_path="/app/data/tasks/1/i3/ip2region_v4.xdb"):
    """尝试加载 ip2region xdb；文件无效（占位/损坏）返回 None"""
    global _IP2REGION
    if _IP2REGION is not None:
        return _IP2REGION
    try:
        with open(xdb_path, "rb") as f:
            data = f.read()
        if len(data) < 1024 * 1024:  # 正版 xdb 约 11MB
            return None
        # xdbSearcher 未安装时仅验证文件有效，查不了 —— 返回特殊标记
        try:
            import xdbSearcher  # noqa
            _IP2REGION = ("ok", xdb_path)
        except ImportError:
            _IP2REGION = ("file_only", xdb_path)
    except OSError:
        _IP2REGION = ("missing", None)
    return _IP2REGION


def p5_ip2region(ip):
    """ip2region 离线库：ISP 字段（官方 README：Country|Province|City|ISP|iso-alpha2-code）"""
    st = _load_ip2region()
    if not st or st[0] == "missing":
        return {"signal": 0, "weight": WEIGHTS["ip2region"], "value": "ip2region xdb缺失",
                "confidence": "unknown", "dim": "ip2region", "detail": ""}
    if st[0] == "file_only":
        # 有 xdb 无 binding：尝试用 stdlib 解析 xdb 头（v4 格式 vIndex 二分）——极简实现
        return _ip2region_stdlib(ip, st[1])
    return {"signal": 0, "weight": WEIGHTS["ip2region"], "value": "ip2region binding可用但未查询",
            "confidence": "unknown", "dim": "ip2region", "detail": ""}


def _ip2region_stdlib(ip, xdb_path):
    """极简 xdb 读取（v4：Header 256B + 索引二分）；失败返回 unknown"""
    try:
        with open(xdb_path, "rb") as f:
            data = f.read()
        # 找 vIndex 指针区：Header 的 [216:224] 和 [224:232]
        vindex_start = struct.unpack("<I", data[216:220])[0]
        vindex_len = struct.unpack("<I", data[220:224])[0]
        if vindex_start + vindex_len > len(data):
            return {"signal": 0, "weight": WEIGHTS["ip2region"], "value": "xdb结构异常",
                    "confidence": "unknown", "dim": "ip2region", "detail": ""}
        # 将 IP 转 uint32
        parts = [int(x) for x in ip.split(".")]
        ipn = (parts[0] << 24) | (parts[1] << 16) | (parts[2] << 8) | parts[3]
        lo, hi = 0, vindex_len // 12 - 1
        while lo <= hi:
            mid = (lo + hi) // 2
            base = vindex_start + mid * 12
            start_ip, _, seg_len = struct.unpack("<IIH", data[base:base + 12])
            if ipn >= start_ip and (mid == vindex_len // 12 - 1 or ipn < struct.unpack("<I", data[base + 12:base + 16])[0]):
                off = base + 12
                rec = data[off:off + seg_len].decode("utf-8", "replace")
                fields = rec.split("|")
                isp = fields[3] if len(fields) > 3 else ""
                if re.search(r"电信|联通|移动|长城|广电|鹏博士|铁通", isp):
                    return {"signal": +1, "weight": WEIGHTS["ip2region"], "value": f"ip2region ISP=家用运营商: {isp}",
                            "confidence": "observed", "dim": "ip2region", "detail": rec}
                if re.search(r"云|IDC|数据中心|托管|腾讯|阿里|华为云|AWS|Azure|GCP|DigitalOcean|Hetzner", isp):
                    return {"signal": -1, "weight": WEIGHTS["ip2region"], "value": f"ip2region ISP=云/IDC: {isp}",
                            "confidence": "observed", "dim": "ip2region", "detail": rec}
                return {"signal": 0, "weight": WEIGHTS["ip2region"], "value": f"ip2region: {isp}",
                        "confidence": "observed", "dim": "ip2region", "detail": rec}
            elif ipn < start_ip:
                hi = mid - 1
            else:
                lo = mid + 1
        return {"signal": 0, "weight": WEIGHTS["ip2region"], "value": "ip2region未命中",
                "confidence": "inferred", "dim": "ip2region", "detail": ""}
    except Exception as e:
        return {"signal": 0, "weight": WEIGHTS["ip2region"], "value": f"ip2region解析失败: {type(e).__name__}",
                "confidence": "unknown", "dim": "ip2region", "detail": str(e)[:120]}


PBL_OK = None  # None=未探测, True/False

def p6_spamhaus(ip, dns="1.1.1.1"):
    """Spamhaus PBL：家宽/动态 IP 应命中（127.0.0.10/11），云不应。
    多递归回退（1.1.1.1 被限流 → 114.114.114.114 → 8.8.8.8 → 系统默认）；
    拒绝码(198.x)/哨兵(127.255.255.x)的源自动跳过。"""
    global PBL_OK
    rev = ".".join(reversed(ip.split(".")))
    q = rev + ".zen.spamhaus.org"
    for d in (dns, "114.114.114.114", "8.8.8.8", ""):
        args = ["dig", "+short", "+time=4", "+tries=2"]
        if d:
            args += [f"@{d}"]
        args += [q]
        rc, out, _ = run_cmd(args, timeout=12)
        if rc != 0:
            continue
        answers = [a.strip() for a in out.splitlines() if a.strip() and not a.strip().startswith(";")]
        # 错误哨兵 / 查询拒绝码：127.255.255.x、198.x → 该源无效,换下一个
        if any(a.startswith(("127.255.255.", "198.")) for a in answers):
            continue
        via = f"@{d}" if d else "system"
        if not answers:
            return {"signal": 0, "weight": WEIGHTS["spamhaus"], "value": "PBL未命中(非动态IP空间)",
                    "confidence": "observed", "dim": "spamhaus", "detail": f"zen via {via} 无 A 记录"}
        # 仅 PBL 精确码 127.0.0.10 / 127.0.0.11 才是"端用户动态IP空间"证据（校准：startswith 127.0.0. 会误吞 SBL/XBL）
        pbl = [a for a in answers if a in ("127.0.0.10", "127.0.0.11")]
        if pbl:
            PBL_OK = True
            return {"signal": +2, "weight": WEIGHTS["spamhaus"], "value": f"命中PBL(端用户动态IP空间): {pbl}",
                    "confidence": "observed", "dim": "spamhaus", "detail": f"answers={answers} via {via}"}
        # SBL/XBL/CSS 黑名单记录(127.0.0.2~9)与是否家宽无关 → 中性,不扣分（校准：原先 -1 误伤）
        PBL_OK = True
        return {"signal": 0, "weight": WEIGHTS["spamhaus"],
                "value": f"Spamhaus有记录但非PBL(黑名单/其他),与家宽判定无关 → 中性",
                "confidence": "observed", "dim": "spamhaus", "detail": f"answers={answers} via {via}"}
    PBL_OK = False
    return {"signal": 0, "weight": WEIGHTS["spamhaus"], "value": "Spamhaus查询失败(所有DNS源被限流/不可达)",
            "confidence": "unknown", "dim": "spamhaus", "detail": ""}


_CLOUD_LIST_CACHE = None

def _load_cloud_lists():
    """云前缀清单（AWS/GCP/DO 官方 + 可选聚合库），缓存到本地；失败降级"""
    global _CLOUD_LIST_CACHE
    if _CLOUD_LIST_CACHE is not None:
        return _CLOUD_LIST_CACHE
    cache_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "cloudlists")
    os.makedirs(cache_dir, exist_ok=True)
    nets = set()
    srcs = []
    jobs = [
        ("aws", "https://ip-ranges.amazonaws.com/ip-ranges.json", "json", "prefixes", "ip_prefix"),
        ("gcp", "https://www.gstatic.com/ipranges/cloud.json", "json", "prefixes", "ipv4Prefix"),
        ("do", "https://www.digitalocean.com/geo/google.csv", "csv", None, 0),
    ]
    for name, url, kind, key, field in jobs:
        fp = os.path.join(cache_dir, name + "." + ("json" if kind == "json" else "csv"))
        fresh = False
        if not os.path.exists(fp) or (time.time() - os.path.getmtime(fp)) > 86400 * 6:
            try:
                with urllib.request.urlopen(url, timeout=12) as r:
                    raw = r.read()
                with open(fp, "wb") as f:
                    f.write(raw)
                fresh = True
            except Exception:
                pass  # 网络失败用旧缓存
        try:
            with open(fp, "rb") as f:
                raw = f.read()
        except OSError:
            continue
        try:
            if kind == "json":
                d = json.loads(raw.decode())
                for p in d.get(key, []):
                    v = p.get(field) or p.get("ipv6Prefix") or p.get("ip_prefix")
                    if v:
                        nets.add(v)
            else:  # csv
                for ln in raw.decode("latin1").splitlines():
                    if ln.strip() and not ln.startswith("Network"):
                        nets.add(ln.strip().split(",")[0])
            srcs.append(name + ("(fresh)" if fresh else "(cache)"))
        except Exception:
            pass
    _CLOUD_LIST_CACHE = (nets, srcs)
    return _CLOUD_LIST_CACHE


def ip_in_cidr(ip, net):
    ipn = struct.unpack(">I", socket.inet_aton(ip))[0]
    net, _, cidr = net.partition("/")
    if not cidr:
        cidr = "32"
    try:
        netn = struct.unpack(">I", socket.inet_aton(net))[0]
    except OSError:
        return False
    bits = int(cidr)
    mask = (0xFFFFFFFF << (32 - bits)) & 0xFFFFFFFF
    return (ipn & mask) == (netn & mask)


def p7_cloudlist(ip):
    """云前缀清单命中 → 强排除"""
    nets, srcs = _load_cloud_lists()
    if not nets:
        return {"signal": 0, "weight": WEIGHTS["cloudlist"], "value": "云清单不可用(下载失败无缓存)",
                "confidence": "unknown", "dim": "cloudlist", "detail": ""}
    for net in nets:
        try:
            if ip_in_cidr(ip, net):
                return {"signal": -2, "weight": WEIGHTS["cloudlist"], "value": f"命中云前缀: {net}",
                        "confidence": "observed", "dim": "cloudlist", "detail": f"sources={srcs}"}
        except Exception:
            continue
    return {"signal": 0, "weight": WEIGHTS["cloudlist"], "value": "未命中云前缀",
            "confidence": "observed", "dim": "cloudlist", "detail": f"sources={srcs}"}


# =====================================================================
# 主动侧：A1-A6 / B1 / C / D1 / E1
# =====================================================================

def a1_router_admin(ip, open_ports):
    """A1 路由器管理口指纹（80/443/8080/8443）"""
    for port in ROUTER_PORTS:
        if not open_ports.get(port):
            continue
        r = http_get(ip, port, timeout=4)
        if not r:
            continue
        status, hdrs, body = r
        blob = " ".join([status, hdrs.get("server", ""), hdrs.get("www-authenticate", ""),
                         body.decode("latin1", "replace")[:2500]])
        for rx, brand in ROUTER_FP:
            if rx.search(blob):
                return {"signal": +2, "weight": WEIGHTS["router_admin"],
                        "value": f"识别到家用路由器管理页: {brand} (port {port})",
                        "confidence": "observed", "dim": "router_admin", "detail": blob[:200]}
        # 401 + Basic realm 也常见于路由器/NAS
        if "401" in status and "basic" in hdrs.get("www-authenticate", "").lower():
            return {"signal": +1, "weight": WEIGHTS["router_admin"],
                    "value": f"HTTP 401 Basic(疑似设备管理页) port {port}",
                    "confidence": "inferred", "dim": "router_admin", "detail": status}
    return {"signal": 0, "weight": WEIGHTS["router_admin"], "value": "未识别路由器管理页",
            "confidence": "observed", "dim": "router_admin", "detail": ""}


def a2_ssdp(ip, timeout=3.0):
    """A2 UPnP/SSDP：单播 M-SEARCH 到目标:1900（组播对远端目标无意义，只做单播）"""
    MSG = (b'M-SEARCH * HTTP/1.1\r\nHost: 239.255.255.250:1900\r\n'
           b'Man: "ssdp:discover"\r\nMX: 2\r\nST: ssdp:all\r\n\r\n')
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.settimeout(timeout)
        s.sendto(MSG, (ip, 1900))
        found = []
        try:
            while True:
                data, addr = s.recvfrom(4096)
                if addr[0] == ip:
                    found.append(data.decode("latin1", "replace"))
        except socket.timeout:
            pass
        s.close()
    except OSError:
        return {"signal": 0, "weight": WEIGHTS["ssdp"], "value": "SSDP发送失败",
                "confidence": "unknown", "dim": "ssdp", "detail": ""}
    if not found:
        return {"signal": 0, "weight": WEIGHTS["ssdp"], "value": "无SSDP响应(云/VPS常态)",
                "confidence": "observed", "dim": "ssdp", "detail": ""}
    for resp in found:
        if re.search(r"200 OK", resp, re.I):
            loc = re.search(r"(?im)^Location:\s*(\S+)", resp)
            if loc and ip in loc.group(1):
                return {"signal": +2, "weight": WEIGHTS["ssdp"],
                        "value": f"SSDP响应 Location指向目标自身: {loc.group(1)}（强家宽信号）",
                        "confidence": "observed", "dim": "ssdp", "detail": resp[:300]}
            return {"signal": +1, "weight": WEIGHTS["ssdp"],
                    "value": f"SSDP 200 OK响应(目标暴露UPnP): {resp[:120]}",
                    "confidence": "observed", "dim": "ssdp", "detail": resp[:300]}
    return {"signal": 0, "weight": WEIGHTS["ssdp"], "value": "SSDP响应非200OK",
            "confidence": "inferred", "dim": "ssdp", "detail": found[0][:200]}


def a3_mdns(ip, timeout=2.0):
    """A3 mDNS：向目标:5353 发 PTR 查询 _services._dns-sd._udp.local"""
    try:
        # DNS PTR query: _services._dns-sd._udp.local
        qname = b"\x09_services\x07_dns-sd\x04_udp\x05local\x00"
        hdr = struct.pack(">HHHHHH", 0, 0, 0x0001, 1, 0, 0)  # ID=0, flags=0x0100 RD
        pkt = hdr + qname + struct.pack(">HH", 12, 1)  # QTYPE=PTR, QCLASS=IN
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.settimeout(timeout)
        s.sendto(pkt, (ip, 5353))
        try:
            data, addr = s.recvfrom(4096)
            s.close()
            if addr[0] == ip and len(data) > 12:
                return {"signal": +1, "weight": WEIGHTS["mdns"], "value": "mDNS有响应(家庭设备特征)",
                        "confidence": "observed", "dim": "mdns", "detail": data[:80].hex()}
        except socket.timeout:
            s.close()
            return {"signal": 0, "weight": WEIGHTS["mdns"], "value": "mDNS无响应",
                    "confidence": "observed", "dim": "mdns", "detail": ""}
    except OSError:
        return {"signal": 0, "weight": WEIGHTS["mdns"], "value": "mDNS发送失败",
                "confidence": "unknown", "dim": "mdns", "detail": ""}
    return {"signal": 0, "weight": WEIGHTS["mdns"], "value": "mDNS无响应",
            "confidence": "observed", "dim": "mdns", "detail": ""}


def a4_gaming_ports(open_ports):
    """A4 游戏/P2P 端口（弱正向：家庭用户自建服务/映射）"""
    hits = [p for p in GAMING_PORTS if open_ports.get(p)]
    if hits:
        return {"signal": +1, "weight": WEIGHTS["gaming"],
                "value": f"游戏/P2P端口开放: {hits}（可能家庭端口映射）",
                "confidence": "observed", "dim": "gaming", "detail": str(hits)}
    return {"signal": 0, "weight": WEIGHTS["gaming"], "value": "游戏/P2P端口均关闭",
            "confidence": "observed", "dim": "gaming", "detail": ""}


def a5_weak_ports(open_ports):
    """A5 22/3389（弱/中性，不可单判）"""
    hits = [p for p in WEAK_PORTS if open_ports.get(p)]
    if hits:
        return {"signal": 0, "weight": WEIGHTS["weak_ports"],
                "value": f"弱信号端口开放: {hits}（SSH在路由器常见;RDP多为家庭PC映射,不可单判）",
                "confidence": "observed", "dim": "weak_ports", "detail": str(hits)}
    return {"signal": 0, "weight": WEIGHTS["weak_ports"], "value": "22/3389关闭",
            "confidence": "observed", "dim": "weak_ports", "detail": ""}


def a6_dc_ports(open_ports):
    """A6 数据中心端口组合（25+邮件/数据库/面板 ≥2 → 排除）"""
    hits = [p for p in DC_PORTS if open_ports.get(p)]
    if len(hits) >= 2:
        return {"signal": -2, "weight": WEIGHTS["dc_ports"],
                "value": f"数据中心端口组合开放: {hits}（SMTP/DB/面板=服务器特征）",
                "confidence": "observed", "dim": "dc_ports", "detail": str(hits)}
    if hits:
        return {"signal": 0, "weight": WEIGHTS["dc_ports"],
                "value": f"部分DC端口开放(不足组合): {hits}", "confidence": "observed",
                "dim": "dc_ports", "detail": str(hits)}
    return {"signal": 0, "weight": WEIGHTS["dc_ports"], "value": "无DC端口开放",
            "confidence": "observed", "dim": "dc_ports", "detail": ""}


def b1_ttl(ip):
    """B1 ICMP TTL → 初始 TTL（弱佐证；ICMP 屏蔽=无法取证≠负分）"""
    ttl = icmp_ping(ip)
    if ttl is None:
        return {"signal": 0, "weight": WEIGHTS["ttl"], "value": "ICMP无响应/被屏蔽(家宽常态,无法取证)",
                "confidence": "unknown", "dim": "ttl", "detail": ""}
    init = initial_ttl(ttl)
    if init == 128:
        return {"signal": +1, "weight": WEIGHTS["ttl"], "value": f"初始TTL=128(Windows,可能端口映射家用机)",
                "confidence": "observed", "dim": "ttl", "detail": f"observed_ttl={ttl}"}
    if init in (64, 255):
        return {"signal": 0, "weight": WEIGHTS["ttl"], "value": f"初始TTL={init}(Unix/路由/网络设备,不单判)",
                "confidence": "observed", "dim": "ttl", "detail": f"observed_ttl={ttl}"}
    return {"signal": 0, "weight": WEIGHTS["ttl"], "value": f"初始TTL={init}",
            "confidence": "observed", "dim": "ttl", "detail": f"observed_ttl={ttl}"}


def c_traceroute(ip, timeout=30):
    """C traceroute 末跳特征词。优先系统 traceroute；缺失降级 Python UDP traceroute"""
    rc, out, _ = run_cmd(["traceroute", "-T", "-p", "80", "-m", "18", "-q", "1", "-w", "2", ip], timeout=timeout)
    if rc is None or rc != 0 or not out:
        # 降级：Python UDP traceroute
        return _py_traceroute(ip)
    return _parse_traceroute(out)


def _parse_traceroute(out):
    hops = []
    for ln in out.splitlines()[1:]:
        parts = ln.split()
        if len(parts) >= 3 and parts[1] != "*":
            hops.append({"hop": parts[0], "target": parts[1]})
    if not hops:
        return {"signal": 0, "weight": WEIGHTS["traceroute"], "value": "traceroute全超时(可能NAT/防火墙)",
                "confidence": "inferred", "dim": "traceroute", "detail": out[:300]}
    last = hops[-1]["target"]
    if TR_ACCESS_RX.search(last):
        return {"signal": +2, "weight": WEIGHTS["traceroute"],
                "value": f"末跳含ISP接入设备特征词: {last}",
                "confidence": "observed", "dim": "traceroute", "detail": " | ".join(h["target"] for h in hops[-3:])}
    if TR_DC_RX.search(last):
        return {"signal": -1, "weight": WEIGHTS["traceroute"],
                "value": f"末跳含机房特征词: {last}",
                "confidence": "observed", "dim": "traceroute", "detail": " | ".join(h["target"] for h in hops[-3:])}
    return {"signal": 0, "weight": WEIGHTS["traceroute"],
            "value": f"末跳无特征词: {last}",
            "confidence": "observed", "dim": "traceroute", "detail": " | ".join(h["target"] for h in hops[-3:])}


def _py_traceroute(ip, max_hops=18, timeout=1.2, udp_port=33434):
    """Python UDP traceroute：递增 TTL 探测，ICMP 错误判定每跳；返回同 _parse_traceroute 结构"""
    try:
        icmp = socket.socket(socket.AF_INET, socket.SOCK_RAW, socket.IPPROTO_ICMP)
        icmp.settimeout(timeout)
    except PermissionError:
        return {"signal": 0, "weight": WEIGHTS["traceroute"], "value": "traceroute不可用(无系统命令+无raw权限)",
                "confidence": "unknown", "dim": "traceroute", "detail": ""}
    hops = []
    dest_reached = False
    for ttl in range(1, max_hops + 1):
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.setsockopt(socket.IPPROTO_IP, socket.IP_TTL, ttl)
        s.settimeout(timeout)
        probe_port = udp_port + ttl
        s.sendto(b"", (ip, probe_port))
        t0 = time.time()
        got = False
        while time.time() - t0 < timeout:
            try:
                pkt, addr = icmp.recvfrom(512)
            except socket.timeout:
                break
            # ICMP header: type(0), code(1)
            if len(pkt) < 28:
                continue
            icmp_type = pkt[20]
            # 解析内嵌 IP 头得到原目的端口
            try:
                inner_src_ip = socket.inet_ntoa(pkt[28:32])
            except OSError:
                continue
            # 找到我们 probe 的内嵌 UDP 目的端口：inner IP 头长 = (pkt[28]&0x0f)*4
            ihl = (pkt[28] & 0x0f) * 4
            if len(pkt) >= 28 + ihl + 8:
                inner_dport = struct.unpack(">H", pkt[28 + ihl + 2:28 + ihl + 4])[0]
                if inner_dport != probe_port:
                    continue
            if icmp_type == 11:  # TTL exceeded
                hops.append({"hop": ttl, "target": addr[0]})
                got = True
                break
            elif icmp_type == 3:  # destination unreachable
                hops.append({"hop": ttl, "target": addr[0]})
                got = True
                dest_reached = True
                break
        s.close()
        if dest_reached:
            break
        if not got:
            hops.append({"hop": ttl, "target": "*"})
    icmp.close()
    real = [h for h in hops if h["target"] != "*"]
    if not real or (len(real) <= 1 and re.match(r"^(10\.|172\.(1[6-9]|2\d|3[01])\.|192\.168\.|127\.)", real[0]["target"])):
        # 仅首跳=内网网关/全超时：出口防火墙过滤 UDP 高端口探针，无法取证
        return {"signal": 0, "weight": WEIGHTS["traceroute"],
                "value": "traceroute不可达(出口防火墙过滤UDP探针/目标丢UDP),无法取证",
                "confidence": "unknown", "dim": "traceroute", "detail": f"hops={hops}"}
    last = real[-1]["target"]
    # 末跳==目标 IP 本身 → VPS/服务器特征（目标自回应）
    if last == ip:
        return {"signal": -1, "weight": WEIGHTS["traceroute"],
                "value": f"末跳为目标自身IP: {last}（VPS/服务器特征,目标直接响应）",
                "confidence": "observed", "dim": "traceroute",
                "detail": " | ".join(f"{h['hop']}:{h['target']}" for h in real[-3:])}
    if TR_ACCESS_RX.search(last):
        return {"signal": +2, "weight": WEIGHTS["traceroute"],
                "value": f"末跳含ISP接入设备特征词: {last}",
                "confidence": "observed", "dim": "traceroute",
                "detail": " | ".join(f"{h['hop']}:{h['target']}" for h in real[-3:])}
    if TR_DC_RX.search(last):
        return {"signal": -1, "weight": WEIGHTS["traceroute"],
                "value": f"末跳含机房特征词: {last}",
                "confidence": "observed", "dim": "traceroute",
                "detail": " | ".join(f"{h['hop']}:{h['target']}" for h in real[-3:])}
    return {"signal": 0, "weight": WEIGHTS["traceroute"],
            "value": f"末跳无特征词: {last}",
            "confidence": "observed", "dim": "traceroute",
            "detail": " | ".join(f"{h['hop']}:{h['target']}" for h in real[-3:])}


def d1_tls(ip, open_ports, timeout=5.0):
    """D1 TLS 证书：getpeercert() 字典（stdlib）；cryptography 可选增强。
    自签(issuer==subject/CN品牌)=强家宽；公网CA=排除信号(陷阱:家宽自建站+LE会像服务器)。"""
    if not open_ports.get(443) and not open_ports.get(8443):
        return {"signal": 0, "weight": WEIGHTS["tls"], "value": "443/8443未开放(无TLS取证)",
                "confidence": "observed", "dim": "tls", "detail": ""}
    port = 443 if open_ports.get(443) else 8443
    try:
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        with socket.create_connection((ip, port), timeout=timeout) as raw:
            with ctx.wrap_socket(raw, server_hostname=ip) as tls:
                cert = tls.getpeercert()
                if not cert:
                    return {"signal": 0, "weight": WEIGHTS["tls"], "value": "TLS无证书",
                            "confidence": "unknown", "dim": "tls", "detail": ""}
                subj = _cert_attr(cert.get("subject"))
                iss = _cert_attr(cert.get("issuer"))
                san = cert.get("subjectAltName", ())
                notbefore = cert.get("notBefore", "")
                notafter = cert.get("notAfter", "")
                self_signed = (subj == iss)
                brand_hit = any(rx.search(subj) for rx, _ in ROUTER_FP)
                cn = subj.split(",")[0].replace("CN=", "") if subj else ""
                if self_signed and (brand_hit or re.search(r"TP-?LINK|ASUS|HUAWEI|HG\d|ZXHN|MiWiFi|OpenWrt|DD-WRT|NETGEAR|D-Link|MikroTik|RT-AC\d", cn, re.I)):
                    return {"signal": +2, "weight": WEIGHTS["tls"],
                            "value": f"自签证书+品牌CN: {cn}（设备管理页特征）",
                            "confidence": "observed", "dim": "tls",
                            "detail": f"subject={subj} issuer={iss} san={san}"}
                if self_signed:
                    return {"signal": +1, "weight": WEIGHTS["tls"],
                            "value": f"自签证书(issuer==subject): CN={cn}",
                            "confidence": "observed", "dim": "tls",
                            "detail": f"subject={subj} issuer={iss} notAfter={notafter}"}
                return {"signal": -1, "weight": WEIGHTS["tls"],
                        "value": f"公网CA证书(排除信号): CN={cn}",
                        "confidence": "observed", "dim": "tls",
                        "detail": f"subject={subj} issuer={iss} notAfter={notafter}"}
    except ssl.SSLError as e:
        return {"signal": 0, "weight": WEIGHTS["tls"], "value": f"TLS握手失败: {type(e).__name__}",
                "confidence": "unknown", "dim": "tls", "detail": str(e)[:120]}
    except OSError:
        return {"signal": 0, "weight": WEIGHTS["tls"], "value": "TLS连接失败",
                "confidence": "unknown", "dim": "tls", "detail": ""}


def _cert_attr(entries):
    """ssl getpeercert 的 subject/issuer → 'CN=xx,O=yy' 字符串"""
    if not entries:
        return ""
    parts = []
    for e in entries:
        for k, v in e:
            parts.append(f"{k}={v}")
    return ",".join(parts)


def e1_cdn_headers(ip, open_ports):
    """E1 CDN/边缘响应头 → 强排除"""
    for port in (443, 80):
        if not open_ports.get(port):
            continue
        r = http_get(ip, port, timeout=5)
        if not r:
            continue
        status, hdrs, _ = r
        for rx, name in CDN_HEADER_RX:
            if any(rx.search(k + ":" + v) for k, v in hdrs.items()):
                return {"signal": -2, "weight": WEIGHTS["cdn_headers"],
                        "value": f"CDN/边缘响应头: {name} (port {port})",
                        "confidence": "observed", "dim": "cdn_headers",
                        "detail": json.dumps(dict(list(hdrs.items())[:10]), ensure_ascii=False)}
        # 泛化兜底：Server 头非主流 Web 服务器名 → 仍中性
    return {"signal": 0, "weight": WEIGHTS["cdn_headers"], "value": "无CDN响应头",
            "confidence": "observed", "dim": "cdn_headers", "detail": ""}


# =====================================================================
# 评分 / 交叉验证 / 置信度
# =====================================================================

STRONG_EXCLUDE = {"asn", "ptr", "cdn_headers", "dc_ports", "cloudlist"}  # 出现 -2 即排除
STRONG_HOME = {"router_admin", "ssdp", "spamhaus"}                        # 出现 +2 即强家宽


def _score(items):
    """加权归一化评分：score = Σ(signal*weight)/Σ(有效weight)，范围约[-2,2]"""
    num = sum(it["signal"] * it["weight"] for it in items if it["signal"] != 0)
    den = sum(it["weight"] for it in items if it["signal"] != 0)
    if den == 0:
        return 0.0, 0
    return num / den, len([it for it in items if it["signal"] != 0])


def verdict_for(score):
    for low, name in VERDICT_BANDS:
        if score >= low:
            return name
    return "不确定"


def cross_validate(active, passive, items):
    """交叉验证：主动 vs 被动方向一致性 + 强排除/强家宽覆盖 + 证据冲突"""
    a_score, a_eff = _score(active)
    p_score, p_eff = _score(passive)
    active_sig = "家宽方向" if a_score > 0.15 else ("云方向" if a_score < -0.15 else "中性")
    passive_sig = "家宽方向" if p_score > 0.15 else ("云方向" if p_score < -0.15 else "中性")
    conflicts = []
    # 强排除 / 强家宽
    excl_hits = [it["dim"] for it in items if it["dim"] in STRONG_EXCLUDE and it["signal"] <= -2]
    home_hits = [it["dim"] for it in items if it["dim"] in STRONG_HOME and it["signal"] >= 2]
    if excl_hits and not home_hits:
        return {
            "active_score": a_score, "passive_score": p_score,
            "active_effective": a_eff, "passive_effective": p_eff,
            "cross_consistency": f"主动侧{active_sig}({a_score:+.2f}) vs 被动侧{passive_sig}({p_score:+.2f})",
            "strong_exclude": excl_hits, "strong_home": home_hits,
            "override": "强排除命中且无强家宽证据 → 直接判非家宽(云/IDC)",
            "conflicts": [],
            "note": "先排除再判断规则生效",
        }
    if home_hits and excl_hits:
        conflicts.append(f"强家宽({home_hits}) 与 强排除({excl_hits}) 同时命中 —— 信号冲突,置信度降级")
    if (a_score > 0.15 and p_score < -0.15) or (a_score < -0.15 and p_score > 0.15):
        conflicts.append(f"主动侧{active_sig}与被动侧{passive_sig}方向冲突,需人工复核")
    return {
        "active_score": a_score, "passive_score": p_score,
        "active_effective": a_eff, "passive_effective": p_eff,
        "cross_consistency": f"主动侧{active_sig}({a_score:+.2f}) vs 被动侧{passive_sig}({p_score:+.2f})",
        "strong_exclude": excl_hits, "strong_home": home_hits,
        "override": None, "conflicts": conflicts,
        "note": "无强排除/强家宽覆盖时以加权分为准",
    }


def confidence_level(items, cv):
    eff = len([it for it in items if it["confidence"] != "unknown"])
    if cv.get("conflicts"):
        return "low", f"证据冲突,有效维度{eff}个"
    if eff >= 7:
        return "high", f"有效证据维度{eff}个"
    if eff >= 4:
        return "medium", f"有效证据维度{eff}个"
    return "low", f"有效证据维度仅{eff}个(被动侧CN家宽常见PTR缺失/主动侧无暴露面)"


# =====================================================================
# 主流程
# =====================================================================

def detect(ip, do_active=True, do_passive=True):
    t0 = time.time()
    # 并发 TCP 扫描（主动侧共享一次）
    open_ports = {}
    active_unreliable = False
    if do_active:
        open_ports = tcp_scan(ip, ALL_SCAN_PORTS, timeout=2.5)
        # 主动扫描可信度自检（校准 2026-10-26，DMIT 出口实测）：外部 TCP 全端口假开放且零 banner →
        # 网络层中间设备/代理接受所有握手（connect 成功但无任何数据），主动扫描不可信 → 禁用主动侧，
        # 避免 dc_ports 等端口依赖维度用假端口触发强排除污染判定。
        if open_ports and len(open_ports) >= int(len(ALL_SCAN_PORTS) * 0.7):
            active_unreliable = True
            open_ports = {}

    items = []

    # ---- 被动侧 ----
    if do_passive:
        for fn in (p1_ptr, p2_asn, p3_whois, p4_ipapi, p5_ip2region, p6_spamhaus, p7_cloudlist):
            try:
                items.append(fn(ip))
            except Exception as e:
                items.append({"signal": 0, "weight": 1.0, "value": f"{fn.__name__}异常",
                              "confidence": "unknown", "dim": fn.__name__, "detail": str(e)[:100]})

    # ---- 主动侧 ----
    if do_active:
        if active_unreliable:
            items.append({"signal": 0, "weight": 1.0,
                          "value": "主动扫描不可信(全端口假开放/零banner,网络层中间设备或代理假握手),主动侧已禁用",
                          "confidence": "unknown", "dim": "active_scan",
                          "detail": "校准: 出口网络对目标全TCP端口假connect成功且无数据"})
        else:
            for fn in (lambda: a1_router_admin(ip, open_ports),
                       lambda: a2_ssdp(ip),
                       lambda: a3_mdns(ip),
                       lambda: a4_gaming_ports(open_ports),
                       lambda: a5_weak_ports(open_ports),
                       lambda: a6_dc_ports(open_ports),
                       lambda: b1_ttl(ip),
                       lambda: c_traceroute(ip),
                       lambda: d1_tls(ip, open_ports),
                       lambda: e1_cdn_headers(ip, open_ports)):
                try:
                    items.append(fn())
                except Exception as e:
                    items.append({"signal": 0, "weight": 1.0, "value": "active检查异常",
                                  "confidence": "unknown", "dim": "active", "detail": str(e)[:100]})

    items = [it for it in items if it]  # 防御：任何被动/主动函数返回 None 都不污染列表

    active = [it for it in items if it["dim"] not in ("ptr", "asn", "whois", "ipapi", "ip2region", "spamhaus", "cloudlist")]
    passive = [it for it in items if it["dim"] not in {a["dim"] for a in active}]

    # 校准修正：ip-api mobile=true 时，Spamhaus PBL 命中降级为弱证据（移动动态空间≠家宽，
    # 否则 AT&T Mobility / T-Mobile 等移动网络会被 PBL 误判为家宽）
    if any(it.get("mobile") for it in items):
        for it in items:
            if it["dim"] == "spamhaus" and it["signal"] == 2:
                it["signal"] = 1
                it["value"] += " (mobile=true: 移动动态空间非家宽,降为弱证据)"

    cv = cross_validate(active, passive, items)
    score, eff = _score(items)
    verdict = verdict_for(score)
    if cv["override"]:
        verdict = "非家宽(云/IDC)"
    # 单维度保护（校准）：无强排除/强家宽覆盖且 n_sign<2 时，唯一有向证据若为 ±2 硬信号则信任，
    # 否则（±1 或 0 证据）降为不确定——拒绝弱/单维度下结论
    n_sign = len([it for it in items if it["signal"] != 0])
    if not cv["override"] and not cv["strong_home"] and n_sign < 2:
        hard_only = [it for it in items if it["signal"] != 0 and abs(it["signal"]) >= 2]
        if not (n_sign == 1 and hard_only):
            verdict = "不确定"
            cv["note"] = "有向证据维度<2(唯一证据非±2硬信号),判定证据不足 → 降为不确定"
    conf, conf_note = confidence_level(items, cv)
    result = {
        "ip": ip, "timestamp": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
        "verdict": verdict, "confidence": conf, "confidence_note": conf_note,
        "score": round(score, 3), "effective_checks": eff,
        "cross_validation": cv,
        "checks": items,
        "open_ports": {str(k): v for k, v in open_ports.items() if v},
        "elapsed_s": round(time.time() - t0, 1),
    }
    return result


def fmt(ip, r):
    L = []
    L.append(f"\n{'='*66}")
    L.append(f" 家宽检测 | {ip} | {r['timestamp']}")
    L.append(f"{'='*66}")
    L.append(f" 判定: {r['verdict']}   置信度: {r['confidence']} ({r['confidence_note']})")
    L.append(f" 加权分: {r['score']:+.3f}   有效检查项: {r['effective_checks']}   耗时: {r['elapsed_s']}s")
    L.append(f" 开放端口: {r['open_ports'] or '无(主动面收敛)'}")
    L.append(f" 交叉验证: {r['cross_validation']['cross_consistency']}")
    if r['cross_validation']['strong_exclude']:
        L.append(f"   强排除命中: {r['cross_validation']['strong_exclude']}")
    if r['cross_validation']['strong_home']:
        L.append(f"   强家宽命中: {r['cross_validation']['strong_home']}")
    if r['cross_validation']['override']:
        L.append(f"   {r['cross_validation']['override']}")
    for c in r['cross_validation']['conflicts']:
        L.append(f"   ⚠ {c}")
    L.append(f"\n 检查明细 (signal 加权 → 证据):")
    for it in r["checks"]:
        mark = "+" if it["signal"] > 0 else ("-" if it["signal"] < 0 else ".")
        L.append(f"  [{mark}{abs(it['signal'])}×{it['weight']:.1f} {it['confidence']:8s}] {it['dim']:14s} | {it['value']}")
        if it["detail"]:
            L.append(f"      ↳ {it['detail'][:160]}")
    return "\n".join(L)


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)
    ip = sys.argv[1]
    do_active = do_passive = True
    json_out = False
    if "--json" in sys.argv:
        json_out = True
    if "--no-active" in sys.argv:
        do_active = False
    if "--no-passive" in sys.argv:
        do_passive = False
    r = detect(ip, do_active, do_passive)
    if json_out:
        print(json.dumps(r, indent=2, ensure_ascii=False, default=str))
    else:
        print(fmt(ip, r))
    sys.exit(0)


if __name__ == "__main__":
    main()
